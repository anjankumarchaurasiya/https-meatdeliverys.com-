<div class="mailMessage">
    @if(Request::is('sendTestMail') )       
        {!!$content!!}  
    @endif        
</div>   
