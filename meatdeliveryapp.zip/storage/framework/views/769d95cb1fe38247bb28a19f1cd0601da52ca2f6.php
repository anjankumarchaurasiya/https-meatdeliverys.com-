

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Edit Grocery Item') ,
        'headerData' => __('Grocery Items') ,
        'url' => 'GroceryItem' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Edit Item')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('GroceryItem')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(url('GroceryItem/'.$data->id)); ?>" class="grocery-item" autocomplete="off" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>

                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Item Detail')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                        <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                                        <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($data->name); ?>" required autofocus>
                                                        <?php if($errors->has('name')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('shop_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-shop_id"><?php echo e(__("Item's Shop")); ?></label>
                                                    <select name="shop_id" id="input-shop_id" class="form-control form-control-alternative<?php echo e($errors->has('shop_id') ? ' is-invalid' : ''); ?>"required>
                                                        <option value=""><?php echo e(__('Select Shop')); ?></option>
                                                        <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"<?php echo e($data->shop_id==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>    
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('shop_id')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('shop_id')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            
                                            <div class="col-12">
                                                <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-description"><?php echo e(__('Description')); ?></label>
                                                    <textarea name="description" id="input-description" class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('description')); ?>"required><?php echo e($data->description); ?></textarea>
                                                    <?php if($errors->has('description')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group<?php echo e($errors->has('detail_desc') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-detail_desc"><?php echo e(__('Detail')); ?></label>
                                                    <textarea name="detail_desc" id="input-detail_desc" class="form-control form-control-alternative<?php echo e($errors->has('detail_desc') ? ' is-invalid' : ''); ?>" required><?php echo e($data->detail_desc); ?></textarea>
                                                    <?php if($errors->has('detail_desc')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('detail_desc')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('category_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-category_id"><?php echo e(__("Item's Category")); ?></label>
                                                    <select name="category_id" id="input-category_id" class="form-control form-control-alternative<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>"required>
                                                        <option value=""><?php echo e(__('Select Category')); ?></option>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" <?php echo e($data->category_id==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>    
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('category_id')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('category_id')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('subcategory_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-subcategory_id"><?php echo e(__("Sub Category")); ?></label>
                                                    <select name="subcategory_id" id="input-subcategory_id" class="form-control form-control-alternative<?php echo e($errors->has('subcategory_id') ? ' is-invalid' : ''); ?>"required>
                                                        <option value=""><?php echo e(__('Select Sub Category')); ?></option>
                                                        <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php echo e($data->subcategory_id==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>    
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php if($errors->has('subcategory_id')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('subcategory_id')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('brand') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-brand"><?php echo e(__('Brand')); ?></label>
                                                    <input type="text" name="brand" id="input-brand" class="form-control form-control-alternative<?php echo e($errors->has('brand') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Brand')); ?>" value="<?php echo e($data->brand); ?>">
                                                    <?php if($errors->has('brand')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('brand')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                 <div class="form-group<?php echo e($errors->has('weight') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-weight"><?php echo e(__('Weight')); ?></label>
                                                    <input type="text" name="weight" id="input-weight" class="form-control form-control-alternative<?php echo e($errors->has('weight') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Weight')); ?>" value="<?php echo e($data->weight); ?>">
                                                    <?php if($errors->has('weight')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('weight')); ?></strong>
                                                        </span>
                                                   <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('stock') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-stock"><?php echo e(__('stock')); ?></label>
                                                    <input type="number" name="stock" id="input-stock" class="form-control form-control-alternative<?php echo e($errors->has('stock') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('stock')); ?>" value="<?php echo e($data->stock); ?>" required >
                                                    <?php if($errors->has('stock')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('stock')); ?></strong>
                                                        </span>
                                                   <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('stock_unit') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-stock-unit"><?php echo e(__('Stock Unit')); ?></label>
                                                    <select name="stock_unit" id="input-stock_unit" class="form-control form-control-alternative<?php echo e($errors->has('stock_unit') ? ' is-invalid' : ''); ?>" required>
                                                        <option value=""> <?php echo e(__('Select Item Unit')); ?> </option>
                                                        <option value="kg" <?php echo e($data->stock_unit == 'kg'?'selected':''); ?>> kg </option>
                                                        <option value="gm" <?php echo e($data->stock_unit == 'gm'?'selected':''); ?>> gm </option>
                                                        <option value="ltr" <?php echo e($data->stock_unit == 'ltr'?'selected':''); ?>> ltr </option>
                                                        <option value="ml" <?php echo e($data->stock_unit == 'ml'?'selected':''); ?>> ml </option>
                                                        <option value="unit" <?php echo e($data->stock_unit == 'unit'?'selected':''); ?>> unit </option>
                                                    </select>
                                                    <?php if($errors->has('stock_unit')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong> <?php echo e($errors->first('stock_unit')); ?> </strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="row">
                                                    <div class="col-10">
                                                        <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                            <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                            <div class="custom-file">
                                                                <input type="file"  accept=".png, .jpg, .jpeg, .svg" class="custom-file-input read-image" name="image" id="image">
                                                                <label class="custom-file-label" for="image"><?php echo e(__('Select file')); ?></label>
                                                            </div>
                                                            <?php if($errors->has('image')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('image')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-2">
                                                        <img class=" avatar-lg round-5 view-image" style="width: 100%;height: 90px;" src="<?php echo e(url('images/upload/'.$data->image)); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                                    <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                        <option value="">Select Status</option>
                                                        <option value="0" <?php echo e($data->status=="0" ? 'Selected' : ''); ?>>Available</option>
                                                        <option value="1" <?php echo e($data->status=="1" ? 'Selected' : ''); ?>>Not Available</option>
                                                    </select>
                
                                                    <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('top_featured') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-top_featured"><?php echo e(__('Top Featured')); ?></label>
                                                    <Select name="top_featured" id="input-top_featured" class="form-control form-control-alternative<?php echo e($errors->has('top_featured') ? ' is-invalid' : ''); ?>"  required>
                                                        <option value="0" <?php echo e($data->top_featured=="0" ? 'Selected' : ''); ?>>False</option>
                                                        <option value="1" <?php echo e($data->top_featured=="1" ? 'Selected' : ''); ?>>True</option>
                                                    </select>
        
                                                    <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row flex">
                                        <div class="col-6">
                                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Item Unit Detail')); ?></h6>
                                        </div>
                                        <div class="col-6 text-right">
                                            <button type="button" class="btn btn-success btn-add"> + </button>
                                        </div>
                                    </div>
                                    <div class="pl-lg-4">
                                        <div class="append">
                                            <?php $__currentLoopData = json_decode($data->detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row <?php echo e($key != 0 ? 'mt-3':''); ?>">
                                                    <div class="col-2">
                                                        <label class="form-control-label"> <?php echo e(__("Quantity")); ?> </label>
                                                        <input type="number" value="<?php echo e($item->qty); ?>" name="qty[]" class="form-control form-control-alternative" placeholder="Quantity" required>
                                                    </div>
                                                    <div class="col-2">
                                                        <label class="form-control-label"> <?php echo e(__("Unit")); ?> </label>
                                                        <select name="unit[]" class="form-control form-control-alternative" required>
                                                            <option value=""> Select Item Unit </option>
                                                            <option value="kg" <?php echo e($item->unit == 'kg'?'selected':''); ?>> kg </option>
                                                            <option value="gm" <?php echo e($item->unit == 'gm'?'selected':''); ?>> gm </option>
                                                            <option value="ltr" <?php echo e($item->unit == 'ltr'?'selected':''); ?>> ltr </option>
                                                            <option value="ml" <?php echo e($item->unit == 'ml'?'selected':''); ?>> ml </option>
                                                            <option value="unit" <?php echo e($item->unit == 'unit'?'selected':''); ?>> unit </option>
                                                        </select>
                                                    </div>
                                                    <div class="col-2">
                                                        <label class="form-control-label"> <?php echo e(__("Discounted Price")); ?> </label>
                                                        <input value="<?php echo e($item->price); ?>" type="number" name="price[]" class="form-control form-control-alternative" placeholder="Price" required>
                                                    </div>
                                                    <div class="col-2">
                                                        <label class="form-control-label"> <?php echo e(__('Original Price')); ?> </label>
                                                        <input value="<?php echo e($item->fake_price); ?>" type="number" name="fake_price[]" class="form-control form-control-alternative" placeholder="Fake Price" required>
                                                    </div>
                                                    <div class="col-2 mt-auto">
                                                        <?php if($key != 0): ?>
                                                            <button type="button" class="btn btn-danger btn-remove"> - </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div class="col-12">
                                            <div class="text-center">
                                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Edit Item')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/GroceryItem/editGroceryItem.blade.php ENDPATH**/ ?>