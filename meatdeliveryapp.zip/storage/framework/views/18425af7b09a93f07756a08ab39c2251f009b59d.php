

<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<?php echo $__env->make('toast',Session::get('success'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<div class="header pb-8 pt-5 d-flex pt-lg-8"
    style="background-image: url(<?php echo e(url('admin/images/bg.jpg')); ?>); background-size: cover; background-position: center center;">
    <span class="mask bg-gradient-default opacity-8"></span>
    <div class="container-fluid">

        <div class="header-body">
            <!-- Card stats -->
            <div class="row">
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted"><?php echo e(__('Shops')); ?></h5>
                                    <span class="h2 font-weight-bold"><?php echo e($master['shops']); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                                        <i class="fas fa-store"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted"><?php echo e(__('New users')); ?></h5>
                                    <span class="h2 font-weight-bold"><?php echo e($master['users']); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                                        <i class="fas fa-users"></i>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted"><?php echo e(__('Sales')); ?></h5>
                                    <span class="h2 font-weight-bold"><?php echo e($currency.$master['sales']); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                                        <i class="fas fa-chart-pie"></i>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted"><?php echo e(__('Delivery Guys')); ?></h5>
                                    <span class="h2 font-weight-bold"><?php echo e($master['delivery']); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                        <i class="ni ni-delivery-fast"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mt--7">
    <?php 
        $sell_product =  \App\Setting::find(1)->sell_product;       
    ?>
    
    <?php if($sell_product == 2 || $sell_product == 0): ?>

    <?php if(\App\Setting::find(1)->default_grocery_order_status == "Pending"): ?>
    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Grocery Order Requests')); ?></h3>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(url('GroceryOrder')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('See all')); ?></a>
                        </div>
                    </div>
                </div>

                <div class="table-responsive" id="grocery-pending-order">
                    <?php if(count($groceryOrders)>0): ?>
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo e(__('Order ID')); ?></th>
                                <th scope="col"><?php echo e(__('Customer')); ?></th>
                                <th scope="col"><?php echo e(__('payment')); ?></th>
                                <th scope="col"><?php echo e(__('date')); ?></th>
                                <th scope="col"><?php echo e(__('Payment GateWay')); ?></th>
                                <th scope="col"><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $groceryOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge label label-light-warning"><?php echo e($order->order_no); ?></span></td>
                                <td><?php echo e($order->customer->name); ?></td>
                                <td><?php echo e($currency.$order->payment.'.00'); ?></td>
                                <td><?php echo e($order->date ." | ".$order->time); ?></td>
                                <td><?php echo e($order->payment_type); ?></td>
                                <td>
                                    
                                    <a href="<?php echo e(url('accept-grocery-order/'.$order->id)); ?>" class="table-action"
                                        data-toggle="tooltip" data-original-title="Accept Order">
                                        <i class="fas fa-check-square text-success"></i>
                                    </a>
                                    <a href="<?php echo e(url('reject-grocery-order/'.$order->id)); ?>" class="table-action"
                                        data-toggle="tooltip" data-original-title="Reject Order">
                                        <i class="fas fa-window-close text-danger"></i>
                                    </a>
                                    
                                    <a href="<?php echo e(url('viewGroceryOrder/'.$order->id.$order->order_no)); ?>" class="table-action"
                                        data-toggle="tooltip" data-original-title="View Order">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="empty-state text-center pb-3">
                        <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:30%;height:200px;">
                        <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__("Nothing!!")); ?></h2>
                        <p style="font-weight:600;"><?php echo e(__("Your Collection list is empty....")); ?></p>
                    </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-8">
            <div class="card shadow mb-5">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Our Locations')); ?></h3>
                            <input type="hidden" id="locations" name="locations" value="<?php echo e($locations); ?>">
                            <input type="hidden" id="shops" name="shops" value="<?php echo e($shops); ?>">
                        </div>

                        <div class="col-4 text-right">
                            
                        </div>
                    </div>
                </div>

                <div class="card-body">

                    <div class="vector-map" id="locationMap" style="width: 100%; height: 400px"></div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Categories')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(url('GroceryCategory')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('See all')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(count($category)>0): ?>
                        <ul class="list-group list-group-flush list my--3">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->iteration <= 4): ?> <li class="list-group-item px-0">
                                <div class="row align-items-center">
                                    <div class="col-auto">
                                        <img class=" avatar-lg round-5" src="<?php echo e(url('images/upload/'.$item->image)); ?>">
                                    </div>
                                    <div class="col ml--2">
                                        <h4 class="mb-0">
                                            <a href="#!"><?php echo e($item->name); ?></a>
                                        </h4>
                                        <span class="badge badge-dot mr-4">
                                            <i class="<?php echo e($item->status==0?'bg-success': 'bg-danger'); ?>"></i>
                                            <span class="status"><?php echo e($item->status==0?'Active': 'Block'); ?></span>
                                        </span>
                                    </div>
                                    
                                </div>
                                </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                        </ul>
                        <?php else: ?>
                        <div class="empty-state text-center pb-3">
                            <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:60%;height:200px;">
                            <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__("Nothing!!")); ?></h2>
                            <p style="font-weight:600;"><?php echo e(__("Your Collection list is empty....")); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
        <div class="col-8">
            

<div class="card shadow mb-4">
    <div class="card-header border-0">
        <div class="row align-items-center">
            <div class="col-8">
                <h3 class="mb-0"><?php echo e(__('Our Shops')); ?></h3>
            </div>
            <div class="col-4 text-right">
                <a href="<?php echo e(url('GroceryShop')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('See all')); ?></a>
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <?php if(count($shops)>0): ?>
        <table class="table align-items-center table-flush">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo e(__('Image')); ?></th>
                    <th scope="col"><?php echo e(__('Name')); ?></th>
                    <th scope="col"><?php echo e(__('Location')); ?></th>
                    <th scope="col"><?php echo e(__('Radius')); ?></th>                  
                    <th scope="col"><?php echo e(__('Status')); ?></th>
                    <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                <tr>
                    <th scope="row"> <?php echo e($loop->iteration); ?> </th>
                    <td><img class="avatar-lg round-5" src="<?php echo e(url('images/upload/'.$shop->image)); ?>"></td>
                    <td><?php echo e($shop->name); ?></td>
                    <td><?php echo e($shop->locationData?$shop->locationData->name:'-'); ?></td>
                    <td>
                        <?php echo e($shop->radius.'km'); ?>

                    </td>
                   
                    <td>
                        <span class="badge badge-dot mr-4">
                            <i class="<?php echo e($shop->status==0?'bg-success': 'bg-danger'); ?>"></i>
                            <span class="status"><?php echo e($shop->status==0?'Active': 'Deactive'); ?></span>
                        </span>
                    </td>
                    <td>
                        <div class="dropdown">
                            <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="<?php echo e(url('GroceryShop/'.$shop->name)); ?>"><?php echo e(__('View')); ?></a>
                                <a class="dropdown-item" href="<?php echo e(url('GroceryShop/'.$shop->id.'/edit')); ?>"><?php echo e(__('Edit')); ?></a>
                                <a class="dropdown-item" onclick="deleteData('GroceryShop','<?php echo e($shop->id); ?>');"
                                    href="#"><?php echo e(__('Delete')); ?></a>
                                
                            </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state text-center pb-3">
            <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:40%;height:200px;">
            <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__("Nothing!!")); ?></h2>
            <p style="font-weight:600;"><?php echo e(__("Your Collection list is empty....")); ?></p>
        </div>
        <?php endif; ?>
    </div>

</div>
</div>
<div class="col-4">
    
    <div class="card shadow">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0"><?php echo e(__('Our Items')); ?></h3>
                </div>
                <div class="col-4 text-right">
                    <a href="<?php echo e(url('GroceryItem')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('See all')); ?></a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if(count($items)>0): ?>
            <ul class="list-group list-group-flush list my--3">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <?php if($loop->iteration <= 6): ?> <li class="list-group-item px-0">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <img class=" avatar-lg round-5" src="<?php echo e(url('images/upload/'.$item->image)); ?>">
                        </div>
                        <div class="col ml--2">
                            <h4 class="mb-0">
                                <a href="<?php echo e(url('Item/'.$item->id)); ?>"><?php echo e($item->name); ?></a>
                            </h4>
                            <span class="status"><?php echo e($currency.$item->sell_price.'.00'); ?></span>
                        </div>
                        <div class="col-auto">
                            
                        </div>
                    </div>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
            <div class="empty-state text-center pb-3">
                <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:60%;height:200px;">
                <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__("Nothing!!")); ?></h2>
                <p style="font-weight:600;"><?php echo e(__("Your Collection list is empty....")); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('DashBoard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>