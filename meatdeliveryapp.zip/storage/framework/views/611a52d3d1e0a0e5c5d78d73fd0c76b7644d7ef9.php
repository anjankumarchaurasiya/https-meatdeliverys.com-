

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Grocery Item Gallery') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

        <div class="row">
            <div class="col">
                <div class="card form-card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Grocery Item Gallery')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(url('/GroceryItem/gallery/'.$data->id.'/add')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add New Images')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <?php
                            $imgs = array();
                            if($data->gallery != "" || $data->gallery != null){
                                $imgs = explode(", ",$data->gallery);
                            }
                        ?>
                        <?php if(count($imgs) > 0): ?>
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo e(__('#')); ?></th>
                                        <th scope="col"><?php echo e(__('Image')); ?></th>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><img class=" avatar-lg rou  nd-5" src="<?php echo e(url('images/upload/'.$item)); ?>"></td>
                                            <td>
                                                
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                        <a class="dropdown-item" onclick="deleteItemGallery('<?php echo e($item); ?>','<?php echo e($data->id); ?>')" href="#"><?php echo e(__('Delete')); ?></a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state text-center pb-3">
                                <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:35%;height:220px;">
                                <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__('Nothing!!')); ?></h2>
                                <p style="font-weight:600;"><?php echo e(__('Your Collection list in empty....')); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __('Item Gallery')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/GroceryItem/viewGroceryItemGallery.blade.php ENDPATH**/ ?>