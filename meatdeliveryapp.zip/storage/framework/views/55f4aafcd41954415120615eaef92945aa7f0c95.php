

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Add Driver') ,
        'headerData' => __('Drivers') ,
        'url' => 'deliveryGuys' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Add Driver')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('deliveryGuys')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(url('addDriver')); ?>" autocomplete="off"  enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    
                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Driver information')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="row"> 
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                                    <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                                                    <input type="email" name="email" id="input-email" class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e(old('email')); ?>" required>
                
                                                    <?php if($errors->has('email')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row"> 
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-phone"><?php echo e(__('Phone')); ?></label>
                                                    <input type="text" name="phone" id="input-phone" class="form-control form-control-alternative<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e(old('phone')); ?>" required>
                
                                                    <?php if($errors->has('phone')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('location') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-location"><?php echo e(__('Location')); ?></label>
                                                    <select name="location" id="input-location" class="form-control form-control-alternative<?php echo e($errors->has('location') ? ' is-invalid' : ''); ?>"  required>
                                                        <option value="">Select Location</option>
                                                        <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" <?php echo e(old('location')==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>

                                                    <?php if($errors->has('location')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('location')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group<?php echo e($errors->has('dateOfBirth') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-dateOfBirth"><?php echo e(__('Date of Birth')); ?></label>
                                            <input type="text" name="dateOfBirth" id="dateOfBirth" class="form-control form-control-alternative<?php echo e($errors->has('dateOfBirth') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Date Of Birth')); ?>" value="<?php echo e(old('dateOfBirth')); ?>">
            
                                            <?php if($errors->has('dateOfBirth')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('dateOfBirth')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                                                                                                    
                                        <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                <div class="custom-file">
                                                    <input type="file" accept=".png, .jpg, .jpeg, .svg" class="custom-file-input" name="image" id="image">
                                                    <label class="custom-file-label" for="image">Select file</label>
                                                </div>
                                                <?php if($errors->has('image')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        </div>
                                        
                                        <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-password"><?php echo e(__('Password')); ?></label>
                                            <input type="password" name="password" id="input-password" class="form-control form-control-alternative<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" value="" required>
                                            
                                            <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group <?php echo e($errors->has('password_confirmation') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-password-confirmation"><?php echo e(__('Confirm Password')); ?></label>
                                            <input type="password" name="password_confirmation" id="input-password-confirmation" class="form-control form-control-alternative<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Password')); ?>" value="" required>

                                            <?php if($errors->has('password_confirmation')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('User Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/mainAdmin/users/addDriver.blade.php ENDPATH**/ ?>