<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Add Grocery Category') ,
        'headerData' => __('Grocery Category') ,
        'url' => 'GroceryCategory' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Add Grocery Category')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('GroceryCategory')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(url('GroceryCategory')); ?>" autocomplete="off" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>

                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Grocery Category Detail')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">

                                            <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                            <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                <div class="custom-file">
                                                    <input type="file"  accept=".png, .jpg, .jpeg, .svg" class="custom-file-input" name="image" id="image" required>
                                                    <label class="custom-file-label" for="image">Select file</label>
                                                </div>
                                                <?php if($errors->has('image')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                            <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                <option value="">Select Status</option>
                                                <option value="0" <?php echo e(old('status')=="0" ? 'Selected' : ''); ?>>Avaliable</option>
                                                <option value="1" <?php echo e(old('status')=="1" ? 'Selected' : ''); ?>>Not Avaliable</option>
                                            </select>

                                            <?php if($errors->has('status')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('status')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>



                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __('Add Category')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/mainAdmin/GroceryCategory/addGroceryCategory.blade.php ENDPATH**/ ?>