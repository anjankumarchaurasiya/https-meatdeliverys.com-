
<?php $__env->startSection('title', __('All Categories')); ?>

<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"> <?php echo e(__('Home')); ?> </a></li>
                            <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__('Categories')); ?> </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="all-product-grid">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="product-top-dt">
                        <div class="product-left-title">
                            <h2 class="cat_name"> <?php echo e(__('All Categories')); ?> </h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="product-list-view">
                <div class="row category-by-cat">
                    <?php if(count($data['category']) > 0): ?>
                        <?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6">
                                <a href="<?php echo e(url('category/'.$item->id.'/'.Str::slug($item->name))); ?>" class="single-cat-item bg-white mb-4">
									<div class="icon">
										<img src="<?php echo e($item->imagePath . $item->image); ?>" alt="">
									</div>
									<div class="text"> <?php echo e($item->name); ?> </div>
								</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-lg-12 col-md-12">
                            <div class="how-order-steps">
                                <div class="how-order-icon">
                                    <i class="uil uil-shopping-basket"></i>
                                </div>
                                <h4> <?php echo e(__('No Categories Available')); ?> </h4>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Body End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/frontend/all-category.blade.php ENDPATH**/ ?>