
<?php $__env->startSection('title', __('Contact Us')); ?>

<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"> <?php echo e(__('Home')); ?> </a></li>
                            <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__('Contact Us')); ?> </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="all-product-grid">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="panel-group accordion" id="accordion0">
                        <?php $__currentLoopData = $data['location']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="heading-<?php echo e($item->id); ?>">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapse-<?php echo e($item->id); ?>" href="#" aria-expanded="false" aria-controls="collapse-<?php echo e($item->id); ?>">
                                            <i class="uil uil-location-point chck_icon"></i> <?php echo e($item->name); ?>

                                        </a>
                                    </div>
                                </div>
                                <div id="collapse-<?php echo e($item->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-<?php echo e($item->id); ?>" data-parent="#accordion0" >
                                    <div class="panel-body">
                                        <?php echo e($item->name); ?> <?php echo e(__('Head Office:')); ?><br>
                                        <?php echo e($item->address); ?><br>
                                        <?php echo e($item->description); ?><br>
                                        <div class="color-pink">Tel: <a href="tel:<?php echo e($item->phone); ?>"><?php echo e($item->phone); ?></a></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="contact-title">
                        <h2><?php echo e(__('Submit customer service request')); ?></h2>
                        <p><?php echo e(__('If you have a question about our service or have an issue to report, please send a request and we will get back to you as soon as possible.')); ?></p>
                    </div>
                    <div class="contact-form">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success alert-dismissible show fade">
                                <div class="alert-body">
                                    <button class="close" data-dismiss="alert">
                                        <span>×</span>
                                    </button>
                                        <?php echo e(session('status')); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(url('/user-request')); ?>" method="post" id="user-request-form">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mt-1">
                                <label class="control-label" for="sendername"><?php echo e(__('Full Name')); ?>*</label>
                                <div class="ui search focus">
                                    <div class="ui left icon input swdh11 swdh19">
                                        <input class="prompt srch_explore" type="text" name="name" id="sendername" placeholder="<?php echo e(__('Your Full Name')); ?>" required>
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group mt-1">
                                <label class="control-label" for="emailaddress"><?php echo e(__('Email Address')); ?>*</label>
                                <div class="ui search focus">
                                    <div class="ui left icon input swdh11 swdh19">
                                        <input class="prompt srch_explore" type="email" name="email" id="emailaddress" placeholder="<?php echo e(__('Your Email Address')); ?>" required>
                                    </div>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group mt-1">
                                <label class="control-label" for="sendersubject"><?php echo e(__('Subject')); ?>*</label>
                                <div class="ui search focus">
                                    <div class="ui left icon input swdh11 swdh19">
                                        <input class="prompt srch_explore" type="text" name="subject" id="sendersubject" placeholder="<?php echo e(__('Subject')); ?>" required>
                                    </div>
                                    <?php if($errors->has('subject')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('subject')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group mt-1">	
                                <div class="field">
                                    <label class="control-label" for="sendermessage"><?php echo e(__('Message')); ?>*</label>
                                    <textarea rows="2" class="form-control" id="sendermessage" name="message" placeholder="<?php echo e(__('Write Message')); ?>" required></textarea>
                                </div>
                                <?php if($errors->has('message')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <button class="next-btn16 hover-btn mt-3 user-request" type="submit" data-btntext-sending="Sending..."><?php echo e(__('Submit Request')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>	
</div>
<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/contact-us.blade.php ENDPATH**/ ?>