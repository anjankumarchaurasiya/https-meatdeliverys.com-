
<!DOCTYPE html>
<html lang="en">

	<head>
        <?php
            $company = \App\CompanySetting::first(['logo','name','favicon','logo_dark','responsive_logo']);
        ?>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, shrink-to-fit=9">
		<title><?php echo e($company->name); ?>  | <?php echo e(__("Invoice")); ?></title>
		
		<!-- Favicon Icon -->
		<link rel="icon" type="image/png" href="<?php echo e(url('images/upload/'.$company->favicon)); ?>">
		
		<!-- Stylesheets -->
		<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link href='<?php echo e(asset('frontend/css/unicons.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/style.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/responsive.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/night-mode.css')); ?>' rel='stylesheet'>
		
		<!-- Vendor Stylesheets -->
		<link href="<?php echo e(asset('frontend/css/all.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('frontend/css/semantic.min.css')); ?>" rel="stylesheet">
		
	</head>

<body>
	<!-- Header Start -->
	<header class="header clearfix">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="top-header-group">
						<div class="top-header">
							<div class="res_main_logo">
                                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('images/upload/'.$company->responsive_logo)); ?>" alt=""></a>
							</div>
							<div class="main_logo ml-0" id="logo">
								<a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('images/upload/'.$company->logo)); ?>" alt=""></a>
								<a href="<?php echo e(url('/')); ?>"><img class="logo-inverse" src="<?php echo e(url('images/upload/'.$company->logo_dark)); ?>" alt=""></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<!-- Header End -->
	<!-- Body Start -->
	<div class="bill-dt-bg">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="bill-detail">
                        <div class="bill-dt-step">
                            <div class="bill-title">
                                <h4><?php echo e(__('Items')); ?></h4>
                            </div>
                            <div class="bill-descp">
                                <div class="itm-ttl"><?php echo e(count($order->orderItem)); ?> <?php echo e(__('items')); ?></div>
                                <?php
                                    $subtotal = 0;
                                ?>
                                <?php $__currentLoopData = $order->orderItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="item-prdct"> <?php echo e($item->itemName .' '. $item->unit_qty. $item->unit .' * '. $item->quantity); ?> </span>
                                    <?php
                                        $subtotal = $subtotal + $item->price;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="bill-dt-step">
                            <div class="bill-title">
                                <h4><?php echo e(__('Delivery Address')); ?></h4>
                            </div>
                            <div class="bill-descp">
                                <div class="itm-ttl"><?php echo e($order->address->address_type); ?></div>
                                <p class="bill-address"><?php echo e($order->address['soc_name']); ?>, <?php echo e($order->address->street); ?>, <?php echo e($order->address->city); ?>, <?php echo e($order->address->zipcode); ?></p>
                            </div>
                        </div>
                        <div class="bill-dt-step">
                            <div class="bill-title">
                                <h4><?php echo e(__('Payment')); ?></h4>
                            </div>
                            <div class="bill-descp">
                                <div class="total-checkout-group p-0 border-top-0">
                                    <div class="cart-total-dil">
                                        <h4><?php echo e(__('Subtotal')); ?></h4>
                                        <span> <?php echo e($data["currency"]); ?><?php echo e($subtotal); ?></span>
                                    </div>
                                    <div class="cart-total-dil pt-3">
                                        <h4><?php echo e(__('Discount')); ?></h4>
                                        <span><?php echo e($data["currency"] . $order->discount); ?></span>
                                    </div>
                                    <div class="cart-total-dil pt-3">
                                        <h4><?php echo e(__('Delivery Charges')); ?></h4>
                                        <span><?php echo e($data["currency"] . $order->delivery_charge); ?></span>
                                    </div>
                                </div>
                                <div class="main-total-cart pl-0 pr-0 pb-0 border-bottom-0">
                                    <h2><?php echo e(__('Total')); ?></h2>
                                    <span><?php echo e($data["currency"] . $order->payment); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="bill-dt-step">
                            <div class="bill-title">
                                <h4><?php echo e(__('Delivery Details')); ?></h4>
                            </div>
                            <div class="bill-descp">
                                <p class="bill-dt-sl"><b><?php echo e(__('Location')); ?></b> - <span class="dly-loc"><?php echo e($order->location->name); ?></span></p>
                                <p class="bill-dt-sl"><?php echo e(__('Order ID')); ?> - <span class="descp-bll-dt"><?php echo e($order->order_no); ?></span></p>
                                <p class="bill-dt-sl"><?php echo e(__('Items')); ?> - <span class="descp-bll-dt"><?php echo e(count($order->orderItem)); ?></span></p>
                            </div>
                        </div>
                        <div class="bill-dt-step">
                            <div class="bill-title">
                                <h4><?php echo e(__('Payment Option')); ?></h4>
                            </div>
                            <div class="bill-descp">
                                <p class="bill-dt-sl"><span class="dlr-ttl25 mr-1"><i class="uil uil-check-circle"></i></span>
                                    <?php if($order->payment_type == "COD"): ?>
                                        <?php echo e(__('Cash on Delivery')); ?>

                                    <?php elseif($order->payment_type == "WHATSAPP"): ?>
                                        <?php echo e(__('Whatsapp (Cash on Delivery)')); ?>

                                    <?php else: ?>
                                        <?php echo e($order->payment_type); ?>

                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                        <div class="bill-dt-step">
                            <div class="bill-bottom">
                                <div class="thnk-ordr"><?php echo e(__('Thanks for Ordering')); ?></div>
                                <a class="print-btn hover-btn" id="printPageButton" href="javascript:window.print();"><?php echo e(__('Print')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!-- Body End -->
	
	<!-- Javascripts -->
	<script src="<?php echo e(asset('frontend/js/jquery-3.3.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/semantic.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/night-mode.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/frontend.js')); ?>"></script>
	
	
</body>
</html><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/invoice.blade.php ENDPATH**/ ?>