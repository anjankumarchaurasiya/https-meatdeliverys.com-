<!DOCTYPE html>
<html lang="en">

	<head>
		<?php
			$company = \App\CompanySetting::first(['name','favicon']);
		?>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, shrink-to-fit=9">
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="base_url" content="<?php echo e(url('/')); ?>">
		<title> <?php echo e($company->name); ?>  | <?php echo $__env->yieldContent('title'); ?> </title>
		
		<!-- Favicon Icon -->
		<link rel="icon" type="image/png" href="<?php echo e(url('images/upload/'.$company->favicon)); ?>">
		
		<!-- Stylesheets -->
		<link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		<link href='<?php echo e(asset('frontend/css/unicons.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/style.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/responsive.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/night-mode.css')); ?>' rel='stylesheet'>
		<link href='<?php echo e(asset('frontend/css/step-wizard.css')); ?>' rel='stylesheet'>
		
		<!-- Vendor Stylesheets -->
		<link href="<?php echo e(asset('frontend/css/all.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('frontend/css/owl.carousel.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('frontend/css/owl.theme.default.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('frontend/css/semantic.min.css')); ?>" rel="stylesheet">
		
	</head>

<body>
	<?php
		if(Auth::check())
		{
			if(Auth::user()->role != 0)
				Auth::logout();
		}
	?>
	<!-- start per-loader -->
	<div class="loader-container">
		<div class="loader-ripple">
			<div></div>
			<div></div>
		</div>
	</div>
	<!-- end per-loader -->

	<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldContent('content'); ?>

	<?php echo $__env->make('frontend.model.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('frontend.model.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
	<!-- Javascripts -->
	<script src="<?php echo e(asset('frontend/js/jquery-3.3.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/owl.carousel.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/semantic.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/jquery.countdown.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/product.thumbnail.slider.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/offset_overlay.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/night-mode.js')); ?>"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	 <?php 
		$key = \App\Setting::find(1)->map_key;
		$paypal_on = \App\PaymentSetting::find(1)->paypal;
		$sendbox = \App\PaymentSetting::find(1)->paypalSendbox;
		$cur = \App\Setting::find(1)->currency;
	?>
	<?php if($paypal_on): ?>
		<script src="https://www.paypal.com/sdk/js?client-id=<?php echo e($sendbox); ?>&currency=<?php echo e($cur); ?>"  data-namespace="paypal_sdk"></script>
	<?php endif; ?>
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
	<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
	<script src="https://js.paystack.co/v1/inline.js"></script> 
	<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($key); ?>" async defer></script>
	<script src="<?php echo e(asset('frontend/js/frontend.js')); ?>"></script>
</body>
</html><?php /**PATH /home/groceryat/public_html/resources/views/frontend/layout/master.blade.php ENDPATH**/ ?>