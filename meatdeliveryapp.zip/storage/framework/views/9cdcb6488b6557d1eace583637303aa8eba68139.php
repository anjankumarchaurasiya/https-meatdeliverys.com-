<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <script src="<?php echo e(url('admin/js/jquery.min.js')); ?>"></script>
       <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
        <script>
            var OneSignal = window.OneSignal || [];
            if(OneSignal.length>0){
                setTimeout(() => {
                    OneSignal.getRegistrationId(function(status) {
                    console.log('status',status);
                    });
                }, 2000);

                OneSignal.push(function() {
                OneSignal.init({
                    appId: $('#app_id_web').val(),
                });
                OneSignal.getUserId().then(function(userId) {
                    console.log("OneSignal User ID:", userId);                    
                    $.ajax({
                        headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type:"POST",
                        url:window.location.origin+'/getDeviceToken',
                        data:{  
                        id:userId,
                        },
                        success: function(result){
                        console.log('result ',result)

                        },
                        error: function(err){
                        console.log('err ',err)
                        }
                    });
                });
            });

            }
          
       
        </script>
        <title><?php echo e(\App\CompanySetting::find(1)->name); ?></title>
        <link href="<?php echo e(url('images/upload/'.\App\CompanySetting::find(1)->favicon)); ?>" rel="icon" type="image/png">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
        <link href="<?php echo e(url('admin/css/nucleo.css')); ?>" rel="stylesheet">
        <link href="https://jvectormap.com/css/jquery-jvectormap-2.0.3.css" rel="stylesheet">
        <link href="<?php echo e(url('admin/css/all.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <link rel="stylesheet" href="<?php echo e(url('admin/css/sweetalert2.scss')); ?>">
        <link href="<?php echo e(url('admin/css/animate.css')); ?>" id="theme" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(url('admin/css/bootstrap-wysihtml5.css')); ?>" />
        <link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" id="theme" rel="stylesheet">
        <link href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css" id="theme" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
        <link type="text/css" href="<?php echo e(url('admin/css/argon.css?v=1.0.0')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('admin/css/custom.css')); ?>" rel="stylesheet">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.15/dist/summernote.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    </head>
    <body class="<?php echo e($class ?? ''); ?>">
        <input type="hidden" value="<?php echo e(url('/')); ?>" id="base-url">
        <input type="hidden" value="<?php echo e(\App\Setting::find(1)->web_onesignal_app_id); ?>" id="app_id_web">
        <input type="hidden" value="<?php echo e(Auth::check()?1:0); ?>" id="auth_role">
        <?php if(Auth::check()): ?>
        <?php $status = \App\Setting::find(1)->license_status; ?>
           
            <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-content">
                <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if($status==1): ?>
                        <?php echo $__env->yieldContent('content'); ?>
                        <?php echo $__env->yieldContent('content_setting'); ?>
                    <?php else: ?> 
                        
                        <?php echo $__env->yieldContent('content'); ?>
                        <?php echo $__env->yieldContent('content_setting'); ?>
                    <?php endif; ?>
                <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        <?php else: ?>
            <div class="main-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

        <?php endif; ?>

        <script src="<?php echo e(url('admin/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/sweetalert.all.js')); ?>"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <?php echo $__env->yieldPushContent('js'); ?>

        <script src="<?php echo e(url('admin/js/argon.js?v=1.0.0')); ?>"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

        <script src="<?php echo e(url('admin/js/wysihtml5-0.3.0.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/bootstrap-wysihtml5.js')); ?>"></script>
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
        <script src="<?php echo e(url('admin/js/notify.js')); ?>"></script>
        <?php 
            $key = \App\Setting::find(1)->map_key;
        ?>
        <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($key); ?>" async defer></script>
        
        <script src="<?php echo e(url('admin/js/jquery-jvectormap.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/jquery-jvectormap-world-mill.js')); ?>"></script>
        <script src="http://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
        <script src="<?php echo e(url('admin/js/googleMap.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/charts.js')); ?>"></script>
        <script src="<?php echo e(url('admin/js/lightbox.js')); ?>"></script>
       
        <script src="<?php echo e(url('admin/js/custom.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/groceryat/public_html/resources/views/admin/master.blade.php ENDPATH**/ ?>