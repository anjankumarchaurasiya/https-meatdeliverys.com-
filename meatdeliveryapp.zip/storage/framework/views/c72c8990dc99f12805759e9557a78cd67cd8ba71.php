<head>
    <title><?php echo $__env->yieldContent('title','Order Meat Online | Buy fresh chicken, mutton and fish'); ?></title>
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords','Order chicken online, order mutton online, buy fish online, '); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description','Buy fresh meat at great price from meat deliveries - online meat store near me. Find the best meat products and save big on discounts. Order now '); ?>">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>"/>
</head>

<?php $__env->startSection('title', __('Home')); ?>

<?php $__env->startSection('content'); ?>
	<!-- Body Start -->
	<div class="wrapper">
		<!-- Banner Start -->
		<div class="main-banner-slider">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="owl-carousel offers-banner owl-theme">
							<?php $__currentLoopData = $data['banner']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e($item->url); ?>" target="_blank">
									<div class="item">
										<div class="offer-item">								
											<div class="offer-item-img">
												<div class="gambo-overlay"></div>
												<img src="<?php echo e($item->imagePath . $item->image); ?>" alt="">
											</div>
											<div class="offer-text-dt">
												<div class="offer-top-text-banner">
													<p><?php echo e($item->off); ?> <?php echo e(__('Off')); ?></p>
													<div class="top-text-1"> <?php echo e($item->title2); ?> </div>
													<span> <?php echo e($item->title1); ?> </span>
												</div>
											</div>
										</div>
									</div>
								</a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- Banner End -->

		<!-- Categories Start -->
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span> <?php echo e(__('Shop By')); ?> </span>
								<h2><?php echo e(__('Categories')); ?></h2>
							</div>
						</div>
					</div>
					<?php if(count($data['category']) >= 1): ?>
						<div class="col-md-12">
							<div class="owl-carousel cate-slider owl-theme">
								<?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="item">
										<a href="<?php echo e(url('category/'.$item->id.'/'.Str::slug($item->name))); ?>" class="category-item">
											<div class="cate-img">
												<img src="<?php echo e($item->imagepath .	 $item->image); ?>" alt="">
											</div>
											<h4> <?php echo e($item->name); ?> </h4>
										</a>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					<?php else: ?>
						<div class="col-lg-12 col-md-12">
							<div class="how-order-steps">
								<div class="how-order-icon">
									<i class="uil uil-apps"></i>
								</div>
								<h4> <?php echo e(__('No Category Available')); ?> </h4>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<!-- Categories End -->

		<?php if(count($data['top_featured']) >= 1): ?>
			<!-- Featured Products Start -->
			<div class="section145">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-title-tt">
								<div class="main-title-left">
									<span> <?php echo e(__('For You')); ?> </span>
									<h2> <?php echo e(__('Top Featured Products')); ?> </h2>
								</div>
								<a href="<?php echo e(url('/featured-products')); ?>" class="see-more-btn"> <?php echo e(__('See All')); ?> </a>
							</div>
						</div>
						<div class="col-md-12">
							<div class="owl-carousel featured-slider owl-theme">
								<?php $__currentLoopData = $data['top_featured']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="item">
										<?php echo $__env->make('frontend.model.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Featured Products End -->
		<?php endif; ?>

		<?php if(count($data['coupon']) >= 1): ?>
			<!-- Best Values Offers Start -->
			<div class="section145">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-title-tt">
								<div class="main-title-left">
									<span> <?php echo e(__('Offers')); ?> </span>
									<h2> <?php echo e(__('Best Values')); ?> </h2>
								</div>
							</div>
						</div>
						<?php $__currentLoopData = $data['coupon']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-lg-4 col-md-6">
								<div class="best-offer-item">
									<img src="<?php echo e($item->imagePath . $item->image); ?>" alt="">
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<!-- Best Values Offers End -->
		<?php endif; ?>

		<?php if(count($data['fruits_veg']) >= 1): ?>
			<!-- Vegetables and Fruits Start -->
			<div class="section145">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="main-title-tt">
								<div class="main-title-left">
									<span><?php echo e(__('For You')); ?></span>
									<h2><?php echo e(__('Fresh Vegetables & Fruits')); ?></h2>
								</div>
								<a href="<?php echo e(url('/all-products')); ?>" class="see-more-btn"><?php echo e(__('See All')); ?></a>
							</div>
						</div>
						<div class="col-md-12">
							<div class="owl-carousel featured-slider owl-theme">
								<?php $__currentLoopData = $data['fruits_veg']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="item">
										<?php echo $__env->make('frontend.model.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Vegetables and Fruits Products End -->
		<?php endif; ?>

		<!-- New Products Start -->
		<div class="section145">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="main-title-tt">
							<div class="main-title-left">
								<span><?php echo e(__('For You')); ?></span>
								<h2><?php echo e(__('Added New Products')); ?></h2>
							</div>
							<a href="<?php echo e(url('/all-products')); ?>" class="see-more-btn"><?php echo e(__('See All')); ?></a>
						</div>
					</div>
					<?php if(count($data['new_product']) >= 1): ?>
						<div class="col-md-12">
							<div class="owl-carousel featured-slider owl-theme">
								<?php $__currentLoopData = $data['new_product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="item">
										<?php echo $__env->make('frontend.model.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					<?php else: ?>
						<div class="col-lg-12 col-md-12">
							<div class="how-order-steps">
								<div class="how-order-icon">
									<i class="uil uil-shopping-basket"></i>
								</div>
								<h4> <?php echo e(__('No Product Available')); ?> </h4>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<!-- New Products End -->
	</div>
	<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/home.blade.php ENDPATH**/ ?>