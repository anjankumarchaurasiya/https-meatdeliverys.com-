<div class="col-lg-3 col-md-4">
    <div class="left-side-tabs">
        <div class="dashboard-left-links">
            <a href="<?php echo e(url('/profile/dashboard')); ?>" class="user-item <?php echo e(request()->is('profile/dashboard')  ? 'active' : ''); ?>">
                <i class="uil uil-apps"></i> <?php echo e(__('Overview')); ?>

            </a>
            <a href="<?php echo e(url('/profile/view')); ?>" class="user-item <?php echo e(request()->is('profile/view')  ? 'active' : ''); ?>">
                <i class="uil uil-user"></i> <?php echo e(__('Profile')); ?>

            </a>
            <a href="<?php echo e(url('/profile/change-password')); ?>" class="user-item <?php echo e(request()->is('profile/change-password')  ? 'active' : ''); ?>">
                <i class="uil uil-padlock"></i> <?php echo e(__('Change Password')); ?>

            </a>
            <a href="<?php echo e(url('/profile/orders')); ?>" class="user-item <?php echo e(request()->is('profile/orders')  ? 'active' : ''); ?>">
                <i class="uil uil-box"></i> <?php echo e(__('My Orders')); ?>

            </a>
            <a href="<?php echo e(url('/profile/wishlist')); ?>" class="user-item <?php echo e(request()->is('profile/wishlist')  ? 'active' : ''); ?>">
                <i class="uil uil-heart"></i> <?php echo e(__('Shopping Wishlist')); ?>

            </a>
            <a href="<?php echo e(url('/profile/address')); ?>" class="user-item <?php echo e(request()->is('profile/address')  ? 'active' : ''); ?>">
                <i class="uil uil-location-point"></i> <?php echo e(__('My Address')); ?>

            </a>
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();" class="user-item">
                <i class="uil uil-exit"></i> <?php echo e(__('Logout')); ?>

            </a>
        </div>
    </div>
</div><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/model/user-sidebar.blade.php ENDPATH**/ ?>