
<?php $__env->startSection('title', __('Order Placed')); ?>

<?php $__env->startSection('content'); ?>


	<!-- Body Start -->
	<div class="wrapper">
		<div class="gambo-Breadcrumb">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a></li>
								<li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Order Placed')); ?></li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
		<div class="all-product-grid">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-lg-6 col-md-8">
						<div class="order-placed-dt">
							<i class="uil uil-check-circle icon-circle"></i>
							<h2><?php echo e(__('Order Successfully Placed')); ?></h2>
							<p><?php echo e(__('Thank you for your order! will received order soon')); ?></p>
							<div class="delivery-address-bg">
								<div class="title585">
									<div class="pln-icon"><i class="uil uil-telegram-alt"></i></div>
									<h4><?php echo e(__('Your order will be sent to this address')); ?></h4>
								</div>
								<ul class="address-placed-dt1">
									<li><p><i class="uil uil-map-marker-alt"></i><?php echo e(__('Address')); ?> :<span><?php echo e($order->address['soc_name']); ?>, <?php echo e($order->address->street); ?>, <?php echo e($order->address->city); ?>, <?php echo e($order->address->zipcode); ?>

                                    </span></p></li>
									<li><p><i class="uil uil-phone-alt"></i><?php echo e(__('Phone Number')); ?> :<span><?php echo e(Auth::user()->phone_code . Auth::user()->phone); ?> </span></p></li>
									<li><p><i class="uil uil-envelope"></i><?php echo e(__('Email Address')); ?> :<span><?php echo e(Auth::user()->email); ?> </span></p></li>
									<li><p><i class="uil uil-card-atm"></i><?php echo e(__('Payment Method')); ?> :<span>
										<?php if($order->payment_type == "COD"): ?>
											<?php echo e(__('Cash on Delivery')); ?>

										<?php elseif($order->payment_type == "WHATSAPP"): ?>
											<?php echo e(__('Whatsapp (Cash on Delivery)')); ?>

										<?php else: ?>
											<?php echo e($order->payment_type); ?>

										<?php endif; ?>
									</span></p></li>
								</ul>
								<div class="stay-invoice">
									<div class="st-hm"><?php echo e(__('Stay Home')); ?><i class="uil uil-smile"></i></div>
									<a href="<?php echo e(url('invoice/'.$order->id)); ?>" target="_blank" class="invc-link hover-btn"><?php echo e(__('invoice')); ?></a>
								</div>
								<div class="placed-bottom-dt">
									<?php echo e(__('The payment of')); ?> <span> <?php echo e($data['currency'].$order->payment); ?> </span> <?php echo e(__("you'll make when the deliver arrives with your order.")); ?>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</div>
	<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/orderPlaced.blade.php ENDPATH**/ ?>