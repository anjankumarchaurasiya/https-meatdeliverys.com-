<head>
    <title><?php echo $__env->yieldContent('title','Order Meat Online | Buy fresh chicken, mutton and fish'); ?></title>
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords','Order chicken online, order mutton online, buy fish online, '); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description','Buy fresh meat at great price from meat deliveries - online meat store near me. Find the best meat products and save big on discounts. Order now '); ?>">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>"/>
</head>

<?php
    $curr_url = "http" . (($_SERVER['SERVER_PORT'] == 443) ? "s" : "") . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>

<?php if($curr_url == url('/all-products')): ?>
    <?php $__env->startSection('title', __('All Products')); ?>
<?php else: ?>
    <?php $__env->startSection('title', __('Featured Products')); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"> <?php echo e(__('Home')); ?> </a></li>
                            <?php if($curr_url == url('/all-products')): ?>
                                <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__('All Products')); ?> </li>
                            <?php else: ?>
                                <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__('Featured Products')); ?> </li>
                            <?php endif; ?>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="all-product-grid">
        <div class="container">
            <div class="row">
                <?php if($default_cat != null): ?>
                    <div class="col-lg-12">
                        <div class="product-top-dt">
                            <div class="product-left-title">
                                <h2 class="cat_name"> <?php echo e($default_cat->name); ?> </h2>
                            </div>
                            <div class="product-sort">
                                <div class="ui selection dropdown vchrt-dropdown">
                                    <input name="sort" type="hidden" value="new" id="sort" class="filter-data">
                                    <i class="dropdown icon d-icon"></i>
                                    <div class="text"><?php echo e(__('New Arrival')); ?></div>
                                    <div class="menu">
                                        <div class="item" data-value="new"><?php echo e(__('New Arrival')); ?></div>
                                        <div class="item" data-value="price-asc"> <?php echo e(__('Price - Low to High')); ?> </div>
                                        <div class="item" data-value="price-desc"> <?php echo e(__('Price - High to Low')); ?> </div>
                                        <div class="item" data-value="alphabetical"> <?php echo e(__('Alphabetical')); ?> </div>
                                        <div class="item" data-value="off-desc"> <?php echo e(__('Saving - High to Low')); ?> </div>
                                        <div class="item" data-value="off-asc"> <?php echo e(__('Saving - Low to High')); ?> </div>
                                    </div>
                                </div>
                            </div>
                            <div class="product-sort">
                                <div class="ui selection dropdown vchrt-dropdown">
                                    <input name="category" type="hidden" value="<?php echo e($default_cat->id); ?>" id="category" class="filter-data">
                                    <i class="dropdown icon d-icon"></i>
                                    <div class="text"> <?php echo e($default_cat->name); ?> </div>
                                    <div class="menu">
                                        <?php $__currentLoopData = $data['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item" data-value="<?php echo e($item->id); ?>"> <?php echo e($item->name); ?> </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-lg-12 col-md-12">
                        <div class="how-order-steps">
                            <div class="how-order-icon">
                                <i class="uil uil-shopping-basket"></i>
                            </div>
                            <h4> <?php echo e(__('No Product Available')); ?> </h4>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="product-list-view">
                <div class="row product-list">
                    <?php if(isset($data['products'])): ?>
                        <?php if(count($data['products']) > 0): ?>
                            <?php echo $__env->make('frontend.model.product2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                            <div class="col-lg-12 col-md-12">
                                <div class="how-order-steps">
                                    <div class="how-order-icon">
                                        <i class="uil uil-shopping-basket"></i>
                                    </div>
                                    <h4> <?php echo e(__('No Product Available')); ?> </h4>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($data['products']->currentPage() != $data['products']->lastPage()): ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="more-product-btn">
                                        <button class="show-more-btn hover-btn" id="load-more"> <?php echo e(__('Show More')); ?> </button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Body End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/all-products.blade.php ENDPATH**/ ?>