<?php
	$currency_code = \App\Setting::where('id',1)->first()->currency;
    $data['currency'] = \App\Currency::where('code',$currency_code)->first()->symbol;
	$company = \App\CompanySetting::first(['name']);
	$setting = \App\Setting::first(['delivery_charge']);
	$total = 0;
    $saving = 0;
	foreach ((array) session('cart') as $id => $details) {
		$total += $details['sell_price'];
        $saving += $details['fake_price'];
	}
	$saving = $saving - $total;
	$discount = 0;
	if (session()->exists('coupon')) {
		$coupon = session('coupon');
		if ($coupon->type == 'amount') {
			$discount = $coupon->discount;
		}
		else {
			$discount = ($total * $coupon->discount) / 100;
		}
	}
?>
<!-- Cart Sidebar Offset Start-->
<div class="bs-canvas bs-canvas-left position-fixed bg-cart h-100" id="cart">
	<div class="bs-canvas-header side-cart-header p-3 ">
		<div class="d-inline-block  main-cart-title">
			<?php echo e(__("My Cart")); ?><span>(<span class="cart-item-count m-0"><?php echo e(count((array) session('cart'))); ?></span> Items)</span>
		</div>
		<button type="button" class="bs-canvas-close close" aria-label="Close"><i class="uil uil-multiply"></i></button>
	</div> 
	<div class="bs-canvas-body">
		<div class="cart-top-total">
			<div class="cart-total-dil">
				<h4><?php echo e($company->name); ?></h4>
				<span><?php echo e($data['currency']); ?><span class="cart-main-total"><?php echo e($total); ?></span></span>
			</div>
			<div class="cart-total-dil pt-2">
				<h4><?php echo e(__('Delivery Charges')); ?></h4>
				<span><?php echo e($data['currency']); ?><?php echo e($setting->delivery_charge); ?></span>
			</div>
		</div>
		<div class="side-cart-items">
			<?php if(session('cart')): ?>
                <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="cart-item">
						<div class="cart-product-img">
							<img src="<?php echo e($item['image']); ?>" alt="">
							<div class="offer-badge"> <span class="off_<?php echo e($item['id']); ?>"><?php echo e($item['off']); ?></span>% <?php echo e(__('OFF')); ?></div>
						</div>
						<div class="cart-text">
							<h4> <?php echo e($item['name']); ?> </h4>
							<div class="cart-radio">
								<input type="hidden" name="cart-item-id" value="<?php echo e($item['id']); ?>" class="cart-item-id">
								<input type="hidden" name="cart-item-detail-index-id" value="1" class="cart-item-detail-index-<?php echo e($item['id']); ?> ">
								<ul class="kggrm-now">
									<?php $__currentLoopData = json_decode($item['details']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<input type="radio" id="<?php echo e($item['id'] .'_'.$key); ?>" data-id="<?php echo e($item['id']); ?>" data-index-id="<?php echo e($key); ?>" class="cart-item-detail" name="detail_<?php echo e($item['id']); ?>" <?php echo e($item['detail_index'] == $key? 'checked':''); ?>>
											<label for="<?php echo e($item['id'] .'_'.$key); ?>"> <?php echo e($detail->qty); ?><?php echo e($detail->unit); ?> </label>
										</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
							<div class="qty-group">
								<div class="quantity buttons_added">
									<input type="button" value="-" class="minus minus-btn">
									<input type="number" step="1" name="quantity" min="1" value="<?php echo e($item['qty']); ?>" class="input-text qty cart-qty text qtyOf-<?php echo e($item['id']); ?>">
									<input type="button" value="+" class="plus plus-btn">
								</div>
								<div class="product-price ml-auto">
									<?php echo e($data['currency']); ?><span class="sell_price_<?php echo e($item['id']); ?>"><?php echo e($item['sell_price']); ?></span> 
									<span class="line-through"><?php echo e($data['currency']); ?><span class="fake_price_<?php echo e($item['id']); ?>"><?php echo e($item['fake_price']); ?></span></span>
								</div>
							</div>
							<button type="button" class="cart-close-btn" data-id="<?php echo e($item['id']); ?>"><i class="uil uil-multiply"></i></button>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</div>
	<div class="bs-canvas-footer">
		<?php if($discount != 0): ?>
			<div class="cart-total-dil saving-total">
				<h4><?php echo e(__('Discount')); ?></h4>
				<span><?php echo e($data['currency']); ?><span class="cart-discount"><?php echo e($discount); ?></span></span>
			</div>
		<?php endif; ?>
		<div class="cart-total-dil saving-total">
			<h4><?php echo e(__('Total Saving')); ?></h4>
			<span><?php echo e($data['currency']); ?><span class="cart-saving-total"><?php echo e($saving); ?></span></span>
		</div>
		<div class="main-total-cart">
			<h2> <?php echo e(__('Total')); ?></h2>
			<span><?php echo e($data['currency']); ?><span class="cart-final-total"><?php echo e($total + $setting->delivery_charge - $discount); ?></span></span>
		</div>
		<div class="checkout-cart">
			<a href="<?php echo e(url('/checkout')); ?>" class="cart-checkout-btn hover-btn"> <?php echo e(__('Proceed to Checkout')); ?> </a>
		</div>
	</div>
</div>
<!-- Cart Sidebar Offsetl End--><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/model/cart.blade.php ENDPATH**/ ?>