
<?php $__env->startSection('title', __('FAQ')); ?>

<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?> </a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Frequently Asked Questions')); ?> </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="all-product-grid">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="default-title mt-4">
                        <h2> <?php echo e(__('Frequently Asked Questions')); ?> </h2>
                        <img src="<?php echo e(url('/frontend/images/line.svg')); ?>" alt="">
                    </div>
                    <?php if(count($faq) > 0): ?>
                        <div class="panel-group accordion pt-1" id="accordion0">
                            <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-heading" id="heading<?php echo e($item->id); ?>">
                                        <div class="panel-title">
                                            <a class="collapsed" data-toggle="collapse" data-target="#collapse<?php echo e($item->id); ?>" href="#" aria-expanded="false" aria-controls="collapse<?php echo e($item->id); ?>">
                                                <?php echo e($item->title); ?>

                                            </a>
                                        </div>
                                    </div>
                                    <div id="collapse<?php echo e($item->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($item->id); ?>" data-parent="#accordion0" style="">
                                        <div class="panel-body">
                                            <p><?php echo e($item->description); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="col-lg-12 col-md-12">
                            <div class="how-order-steps">
                                <div class="how-order-icon">
                                    <i class="uil uil-question-circle"></i>
                                </div>
                                <h4> <?php echo e(__('No FAQ Available')); ?> </h4>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>	
</div>
<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/frontend/faq.blade.php ENDPATH**/ ?>