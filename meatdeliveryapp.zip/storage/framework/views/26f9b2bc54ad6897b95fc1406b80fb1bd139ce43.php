<?php
    $company = \App\CompanySetting::first(['email','phone','name']);
    $categories = \App\GroceryCategory::where('status',0)->orderBy('id','desc')->get();
    $locations = \App\Location::where('status',0)->orderBy('id','desc')->get();
?>
	<!-- Footer Start -->
	<footer class="footer">
		<div class="footer-first-row">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6">
						<ul class="call-email-alt">
							<li><a href="tel:<?php echo e($company->phone); ?>" class="callemail"><i class="uil uil-dialpad-alt"></i><?php echo e($company->phone); ?></a></li>
							<li><a href="mailto:<?php echo e($company->email); ?>" class="callemail"><i class="uil uil-envelope-alt"></i><?php echo e($company->email); ?></a></li>
						</ul>
					</div>
					<div class="col-md-6 col-sm-6">
						<div class="social-links-footer">
							<ul>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
								<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
								<li><a href="#"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
							</ul>
						</div>
					</div>				
				</div>
			</div>
		</div>
		<div class="footer-second-row">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-6">
						<div class="second-row-item">
							<h4> <?php echo e(__('Categories')); ?> </h4>
							<ul>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e(url('category/'.$item->id.'/'.Str::slug($item->name))); ?>"> <?php echo e($item->name); ?> </a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<li><a href="<?php echo e(url('/all-categories')); ?>"> <?php echo e(__('All Category')); ?> </a></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6">
						<div class="second-row-item">
							<h4> <?php echo e(__('Useful Links')); ?> </h4>
							<ul>
								<li><a href="<?php echo e(url('/featured-products')); ?>"> <?php echo e(__('Featured Products')); ?> </a></li>
								<li><a href="<?php echo e(url('/offers')); ?>"> <?php echo e(__('Offers')); ?> </a></li>
								<li><a href="<?php echo e(url('/faq')); ?>"><?php echo e(__('Faq')); ?></a></li>
								<li><a href="<?php echo e(url('/contact-us')); ?>"> <?php echo e(__('Contact Us')); ?> </a></li>
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6">
						<div class="second-row-item">
							<h4> <?php echo e(__('Top Cities')); ?> </h4>
							<ul>
								<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><?php echo e($item->name); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6">
						<div class="second-row-item-app">
							<h4> <?php echo e(__('Download App')); ?> </h4>
							<ul>
								<li><a href="#"><img class="download-btn" src="<?php echo e(url('frontend/images/download-1.svg')); ?>" alt=""></a></li>
								<li><a href="#"><img class="download-btn" src="<?php echo e(url('frontend/images/download-2.svg')); ?>" alt=""></a></li>
							</ul>
						</div>
						<div class="second-row-item-payment">
							<h4> <?php echo e(__('Payment Method')); ?> </h4>
							<div class="footer-payments">
								<ul id="paypal-gateway" class="financial-institutes">
									<li class="financial-institutes__logo">
									  <img alt="Visa" title="Visa" src="<?php echo e(url('frontend/images/footer-icons/pyicon-6.svg')); ?>">
									</li>
									<li class="financial-institutes__logo">
									  <img alt="Visa" title="Visa" src="<?php echo e(url('frontend/images/footer-icons/pyicon-1.svg')); ?>">
									</li>
									<li class="financial-institutes__logo">
									  <img alt="MasterCard" title="MasterCard" src="<?php echo e(url('frontend/images/footer-icons/pyicon-2.svg')); ?>">
									</li>
									<li class="financial-institutes__logo">
									  <img alt="American Express" title="American Express" src="<?php echo e(url('frontend/images/footer-icons/pyicon-3.svg')); ?>">
									</li>
									<li class="financial-institutes__logo">
									  <img alt="Discover" title="Discover" src="<?php echo e(url('frontend/images/footer-icons/pyicon-4.svg')); ?>">
									</li>
								</ul>
							</div>
						</div>
						<?php
							$lang = \App\Language::where('status',1)->get();
							$local = \App\Language::where('name',session('locale'))->first();
							if($local){
								$lang_image="/images/upload/".$local->icon;
							}
							else{
								$lang_image="/images/flag-us.png";
							}
						?>
						<div class="second-row-item-payment">
							<h4><?php echo e(__('Languages')); ?></h4>
							<div class="select_location">
								<div class="ui inline dropdown loc-title">
									<div class="text">
										<?php if(session()->exists('location_id') && session()->exists('location_name')): ?>
											<?php echo e(session('location_name')); ?>

										<?php else: ?>
											<img alt="Image placeholder" src="<?php echo e(asset($lang_image)); ?>" class="flag-icon mt-0">
											<?php echo e(session('locale')); ?>

										<?php endif; ?>
									</div>
									<i class="uil uil-angle-down icon__14"></i>
									<div class="menu dropdown_loc">
										<?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<a href="<?php echo e(url('changeLanguage/'.$item->name)); ?>" class="item channel_item">
												<img alt="Image placeholder"  src="<?php echo e(url('images/upload/'.$item->icon)); ?>" class="flag-icon" > 
												<?php echo e($item->name); ?>

											</a>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer-last-row">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="footer-bottom-links">
							<ul>
								<li><a href="<?php echo e(url('/contact-us')); ?>"> <?php echo e(__('Contact')); ?> </a></li>
								<li><a href="#"> <?php echo e(__('Privacy Policy')); ?> </a></li>
								<li><a href="#"> <?php echo e(__('Term & Conditions')); ?> </a></li>
								<li><a href="#"> <?php echo e(__('Refund & Return Policy')); ?> </a></li>
							</ul>
						</div>
						<div class="copyright-text">
							<i class="uil uil-copyright"></i> <?php echo e(__('Copyright')); ?> <?php echo date('Y'); ?> <b > <?php echo e($company->name); ?> </b>. <?php echo e(__('All rights reserved')); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer End --><?php /**PATH /home/groceryat/public_html/resources/views/frontend/layout/footer.blade.php ENDPATH**/ ?>