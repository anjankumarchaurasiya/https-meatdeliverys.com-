

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Banner') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card form-card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Banner')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(url('Banner/create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add New Banner')); ?></a>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <?php if(count($banner)>0): ?>
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo e(__('Id')); ?></th>
                                        <th scope="col"><?php echo e(__('Image')); ?></th>
                                        <th scope="col"><?php echo e(__('Title 1')); ?></th>
                                        <th scope="col"><?php echo e(__('Title 2')); ?></th>
                                        <th scope="col"><?php echo e(__('Off')); ?></th>
                                        <th scope="col"><?php echo e(__('Status')); ?></th>    
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><img class=" avatar-lg round-5" src="<?php echo e(url('images/upload/'.$item->image)); ?>"></td>
                                            <td><?php echo e($item->title1); ?></td>                                              
                                            <td><?php echo e($item->title2); ?></td>                                              
                                            <td><?php echo e($item->off); ?></td>                                              
                                            <td>
                                                <span class="badge badge-dot mr-4">
                                                    <i class="<?php echo e($item->status==0?'bg-success': 'bg-danger'); ?>"></i>
                                                    <span class="status"><?php echo e($item->status==0?'Active': 'Deactive'); ?></span>
                                                </span>
                                            </td>
                                            <td>                            
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                        <a class="dropdown-item" href="<?php echo e(url('Banner/'.$item->id.'/edit')); ?>"><?php echo e(__('Edit')); ?></a>
                                                        <a class="dropdown-item " onclick="deleteData('Banner','<?php echo e($item->id); ?>');" href="#"><?php echo e(__('Delete')); ?></a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $banner->render(); ?>
                        <?php else: ?> 
                            <div class="empty-state text-center pb-3">
                                <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:35%;height:220px;">
                                <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__('Nothing!!')); ?></h2>
                                <p style="font-weight:600;"> <?php echo e(__('Your Collection list is empty....')); ?> </p>
                            </div> 
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Manage Banner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/mainAdmin/banner/viewBanner.blade.php ENDPATH**/ ?>