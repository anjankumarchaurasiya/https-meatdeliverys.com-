

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Grocery Orders') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                    <div class="card shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Grocery Orders')); ?></h3>
                                </div>                                             
                            </div>
                        </div>
                    </div>                       

                    <div class="table-responsive">
                        <?php if(count($orders)>0): ?>
                            <table class="table data-table align-items-center table-flush" >
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo e(__('#')); ?></th>
                                        <th scope="col"><?php echo e(__('Order ID')); ?></th>
                                        <th scope="col"><?php echo e(__('Customer')); ?></th>                                                   
                                        <th scope="col"><?php echo e(__('payment')); ?></th>    
                                        <th scope="col"><?php echo e(__('date')); ?></th>  
                                        <th scope="col"><?php echo e(__('Delivery Type')); ?></th>                
                                        <th scope="col"><?php echo e(__('Payment GateWay')); ?></th>    
                                        <th scope="col"><?php echo e(__('Order Status')); ?></th>    
                                        <th scope="col"><?php echo e(__('Driver')); ?></th>    
                                        <th scope="col"><?php echo e(__('Payment Status')); ?></th>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>                                            
                                            <td><?php echo e($order->order_no); ?></td>
                                            <td><?php echo e($order->customer->name); ?></td>                                              
                                            <td><?php echo e($currency.$order->payment.'.00'); ?></td>
                                            <td><?php echo e($order->date.' | '.$order->time); ?></td>
                                            <td><?php echo e($order->delivery_type); ?></td>
                                            <td><?php echo e($order->payment_type); ?></td>
                                            <td class="changeGroceryOrderStatus">
                                                <select id="order-<?php echo e($order->id); ?>" name="order_status" class=" form-control" <?php echo e($order->order_status=="Cancel" || $order->order_status=="Delivered" ? 'disabled':''); ?>>
                                                    <option value="Pending"<?php echo e($order->order_status == 'Pending'?'Selected' : ''); ?>>Pending</option>
                                                    <option value="Approved"<?php echo e($order->order_status == 'Approved'?'Selected' : ''); ?>>Shop Approved</option>
                                                    <?php if($order->delivery_type=="delivery"): ?>
                                                    <option value="DriverApproved"<?php echo e($order->order_status == 'DriverApproved'?'Selected' : ''); ?> disabled>Driver Approved</option>
                                                    <?php endif; ?>
                                                    <option value="OrderReady"<?php echo e($order->order_status == 'OrderReady'?'Selected' : ''); ?>>Order is Ready at Store</option>
                                                    <?php if($order->delivery_type=="delivery"): ?>                                                    
                                                    <option value="PickUpGrocery"<?php echo e($order->order_status == 'PickUpGrocery'?'Selected' : ''); ?> disabled>Driver Pickup Grocery at Store</option>                                                  
                                                    <option value="OutOfDelivery"<?php echo e($order->order_status == 'OutOfDelivery'?'Selected' : ''); ?> disabled>Order is Out Of Delivery</option>                                                  
                                                    <option value="DriverReach"<?php echo e($order->order_status == 'DriverReach'?'Selected' : ''); ?> disabled>Order is near to Customer</option>                                                  
                                                    <?php endif; ?>
                                                    <option value="Delivered"<?php echo e($order->order_status == 'Delivered'?'Selected' : ''); ?> <?php echo e($order->delivery_type=="delivery"? 'disabled': ''); ?>>Delivered</option>                                                            
                                                    <option value="Cancel"<?php echo e($order->order_status == 'Cancel'?'Selected' : ''); ?>>Cancel</option>
                                                </select>
                                            </td>
                                            <td>
                                                <select name="order_driver" data-id="<?php echo e($order->id); ?>"  class="form-control select-driver">
                                                    <option value="" <?php echo e($order->deliveryBoy_id == null? 'selected':''); ?>> <?php echo e(__('Select Driver')); ?> </option>
                                                    <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($order->location_id == $item->location): ?>
                                                            <option value="<?php echo e($item->id); ?>" <?php echo e($order->deliveryBoy_id == $item->id? 'selected':''); ?>> <?php echo e($item->name); ?> </option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            
                                            <td>
                                                <span class="badge badge-dot mr-4">
                                                    <i class="<?php echo e($order->payment_status==1?'bg-success': 'bg-warning'); ?>"></i>
                                                    <span class="status"><?php echo e($order->payment_status==1?'Completed': 'Pending'); ?></span>
                                                </span>
                                            </td>
                                            <td>  
                                             <a href="#" class="table-action" data-toggle="tooltip" data-original-title="<?php echo e($order->order_otp); ?>">
                                                                <i class="fas fa-mobile-alt"></i></a>                                                                                                             
                                                <a href="<?php echo e(url('viewGroceryOrder/'.$order->id.$order->order_no)); ?>" class="table-action" data-toggle="tooltip" data-original-title="View Order">
                                                <i class="fas fa-eye"></i></a>
                                                <a href="<?php echo e(url('groceryOrderInvoice/'.$order->id.$order->order_no)); ?>" class="table-action" data-toggle="tooltip" data-original-title="view Invoice">
                                                <i class="fas fa-file-invoice-dollar"></i> </a>    
                                            </td>                                                                           
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $orders->render(); ?>
                            <?php else: ?> 
                                <div class="empty-state text-center pb-3" style="background: #fff;">
                                    <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:35%;height:220px;">
                                    <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__('Nothing!!')); ?></h2>
                                    <p style="font-weight:600;"><?php echo e(__('Your Collection list is empty....')); ?></p>
                                </div> 
                            <?php endif; ?>
                        </div>
                      
            </div>
        </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Orders')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/GroceryOrder/orders.blade.php ENDPATH**/ ?>