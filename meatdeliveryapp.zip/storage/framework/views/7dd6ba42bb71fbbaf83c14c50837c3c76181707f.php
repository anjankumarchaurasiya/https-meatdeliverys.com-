<!-- Top navbar -->
<nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
    <div class="container-fluid">
        <!-- Brand -->
        <?php if(Auth::check()): ?>

        <?php $notification = \App\AdminNotification::where('owner_id',Auth::user()->id)->orderBy('id', 'DESC')->get(); ?>

        <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="<?php echo e(url('home')); ?>"><?php echo e(__('Dashboard')); ?></a>
        <?php elseif(Auth::guard('mainAdmin')->check()): ?> 
        <a class="h4 mb-0 text-white text-uppercase d-none d-lg-inline-block" href="<?php echo e(url('mainAdmin/home')); ?>"><?php echo e(__('Dashboard')); ?></a>
        <?php endif; ?>
        
        <!-- Form -->
        
        <!-- User -->
        <?php if(Auth::check()): ?>
         <?php $image = Auth::user()->image; ?>
        <?php elseif(Auth::guard('mainAdmin')->check()): ?> 
            <?php $image = Auth::guard('mainAdmin')->user()->image;  ?>
        <?php endif; ?>
        <?php 
            $sell_product =  \App\Setting::find(1)->sell_product;
            if($sell_product == 1){ $product = 'Grocery'; }
            if($sell_product == 2){ $product = 'Food'; }
        ?>
        <ul class="navbar-nav align-items-center d-none d-md-flex"> 
            
            
            
            <?php if(Auth::check()): ?>
            
            <?php endif; ?>   
            
            <?php
                $lang = \App\Language::where('status',1)->get();
                $local = \App\Language::where('name',session('locale'))->first();
                if($local){
                    $lang_image="/images/upload/".$local->icon;
                }
                else{
                    $lang_image="/images/flag-us.png";
                }
            ?>  
               
            <li class="nav-item dropdown">
                <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">                       
                        <img alt="Image placeholder"  src="<?php echo e(asset($lang_image)); ?>" class="flag-icon" >                                             
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right py-0 overflow-hidden">
                    <?php $__currentLoopData = $lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('changeLanguage/'.$item->name)); ?>" class="dropdown-item"><img src="<?php echo e(url('images/upload/'.$item->icon)); ?>" class="flag-icon" ><span><?php echo e(__($item->name)); ?></span> </a>                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </li>  
            <li class="nav-item dropdown">
                <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="rounded-circle">
                            <img alt="Image placeholder" class="avatar" src="<?php echo e(url('images/upload/'.$image)); ?>">
                        </span>
                        <div class="media-body ml-2 d-none d-lg-block">
                            <span class="mb-0 text-sm  font-weight-bold">
                                <?php if(Auth::check()): ?>
                                <?php echo e(Auth::user()->name); ?>

                                <?php elseif(Auth::guard('mainAdmin')->check()): ?> 
                                <?php echo e(Auth::guard('mainAdmin')->user()->name); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right  py-0 overflow-hidden">
                    <div class=" dropdown-header noti-title">
                        <h6 class="text-overflow m-0"><?php echo e(__('Welcome')); ?></h6>
                    </div>
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('ownerProfile')); ?>" class="dropdown-item">
                            <i class="ni ni-single-02"></i>
                            <span><?php echo e(__('My profile')); ?></span>
                        </a>
                        
                        <a href="<?php echo e(url('OwnerSetting')); ?>" class="dropdown-item">
                            <i class="ni ni-settings-gear-65"></i>
                            <span><?php echo e(__('Settings')); ?></span>
                        </a>
                    <?php elseif(Auth::guard('mainAdmin')->check()): ?> 
                        <a href="<?php echo e(url('adminProfile')); ?>" class="dropdown-item">
                            <i class="ni ni-single-02"></i>
                            <span><?php echo e(__('My profile')); ?></span>
                        </a>
                        <a href="<?php echo e(url('adminSetting')); ?>" class="dropdown-item">
                            <i class="ni ni-settings-gear-65"></i>
                            <span><?php echo e(__('Settings')); ?></span>
                        </a>
                    <?php endif; ?>
                   
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"  onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                        style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
    </div>
</nav><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/layout/header.blade.php ENDPATH**/ ?>