<?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-6">
        <div class="product-item mb-30">
            <a href="<?php echo e(url('product/'.$item['id'] .'/'.Str::slug($item['name']))); ?>" class="product-img">
                <img src="<?php echo e($item['imagePath'] . $item['image']); ?>" alt="">
                <div class="product-absolute-options">
                    <span class="offer-badge-1"><?php echo e($item['off']); ?>% <?php echo e(__('off')); ?></span>
                    <span class="like-icon like-<?php echo e($item['id']); ?> <?php echo e($item['isWishlist'] == 1? 'liked':''); ?>" data-id="<?php echo e($item['id']); ?>" title="wishlist"></span>
                </div>
            </a>
            <div class="product-text-dt">
                <?php if($item['stock'] <= 0): ?>
                    <p> <?php echo e(__('Not Available')); ?> <span> <?php echo e(__('(Out Of Stock)')); ?> </span></p>
                <?php else: ?>
                    <p> <?php echo e(__('Available')); ?> <span> <?php echo e(__('(In Stock)')); ?> </span></p>
                <?php endif; ?>
                <h4> <?php echo e($item['name']); ?> </h4>
                <div class="product-price">
                    <?php echo e($data['currency']); ?><span class="sell_price"><?php echo e($item['sell_price']); ?></span>
					<span class="line-through"><?php echo e($data['currency']); ?><span class="fake_price"><?php echo e($item['fake_price']); ?></span></span>
                </div>
                <div class="qty-cart">
                    <div class="quantity buttons_added">
                        <input type="button" value="-" class="minus minus-btn">
                        <input type="number" step="1" name="quantity" min="1" value="<?php echo e($item['qtyCount']); ?>" class="input-text qty text qtyOf-<?php echo e($item['id']); ?>">
                        <input type="button" value="+" class="plus plus-btn">
                    </div>
                    <span class="cart-icon add-to-cart cart-<?php echo e($item['id']); ?> <?php echo e($item['isCart'] == 1? 'pri-color':''); ?>" data-id="<?php echo e($item['id']); ?>"><i class="uil uil-shopping-cart-alt"></i></span>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/model/product2.blade.php ENDPATH**/ ?>