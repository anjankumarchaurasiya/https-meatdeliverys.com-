

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Add Grocery Coupon') ,
        'headerData' => __('Grocery Coupon') ,
        'url' => 'GroceryCoupon' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Add Coupon')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('GroceryCoupon')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" id="add-coupon-form" action="<?php echo e(url('GroceryCoupon')); ?>" autocomplete="off" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>

                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Coupon Detail')); ?></h6>
                                    <div class="pl-lg-4">
                
                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-name"><?php echo e(__('Coupon Name')); ?></label>
                                            <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-description"><?php echo e(__('Description')); ?></label>
                                            <textarea name="description" id="input-description" class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Description')); ?>"  ><?php echo e(old('description')); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                    <div class="form-group<?php echo e($errors->has('location_id') ? ' has-danger' : ''); ?>">
                                                        <label class="form-control-label" for="input-location_id"><?php echo e(__('Location')); ?></label>
                                                        <select name="location_id" id="input-location_id" class="form-control form-control-alternative<?php echo e($errors->has('location_id') ? ' is-invalid' : ''); ?>" required >
                                                            <option value=""> <?php echo e(__('Select Location')); ?> </option>
                                                            <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>"<?php echo e(old('location_id')==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php if($errors->has('location_id')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('location_id')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('max_use') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-max_use"><?php echo e(__('Maximum Usage')); ?></label>
                                                    <input type="number" min="0" name="max_use" id="input-max_use" class="form-control form-control-alternative<?php echo e($errors->has('max_use') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Maximum Usage')); ?>" value="<?php echo e(old('max_use')); ?>" required >
                                                    <?php if($errors->has('max_use')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('max_use')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="col-2">
                                                <label class="form-control-label" for="input-description"><?php echo e(__('Counpon Type:')); ?></label>
                                            </div>
                                            <div class="col-4">
                                                <div class="form-group<?php echo e($errors->has('type') ? ' has-danger' : ''); ?>">
                                                    <div class="row">
                                                        <div class="col-4"> <label class="form-control-label"><?php echo e(__('Amount')); ?></label></div>
                                                        <div class="col-8">
                                                            <label class="custom-toggle">
                                                                <input type="radio" value="amount" name="type" checked>
                                                                <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-4"> <label class="form-control-label"><?php echo e(__('Percentage')); ?></label></div>
                                                        <div class="col-8">
                                                            <label class="custom-toggle">
                                                                <input type="radio" value="percentage" name="type" >
                                                                <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('discount') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-discount"><?php echo e(__('Discount')); ?><span id="coupon_type_label"> <?php echo e(__('(In Amount)')); ?></span> </label>
                                                    <input type="number" min="0" name="discount" id="input-discount" class="form-control form-control-alternative<?php echo e($errors->has('discount') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Discount')); ?>" value="<?php echo e(old('discount')); ?>" required >
                                                    <?php if($errors->has('discount')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('discount')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('start_date') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="coupon_start_date"><?php echo e(__('Activate Date')); ?></label>
                                                    <input type="text" name="start_date" id="coupon_start_date" class="form-control form-control-alternative<?php echo e($errors->has('start_date') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Activate Date')); ?>" value="<?php echo e(old('start_date')); ?>" required style="background:#fff;" >
                                                    <?php if($errors->has('start_date')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('start_date')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                                        <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                                        <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                            <option value="">Select Status</option>
                                                            <option value="0" <?php echo e(old('status')=="0" ? 'Selected' : ''); ?>>Active</option>
                                                            <option value="1" <?php echo e(old('status')=="1" ? 'Selected' : ''); ?>>Deactive</option>
                                                        </select>

                                                        <?php if($errors->has('status')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('status')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                <div class="custom-file">
                                                    <input type="file"  accept=".png, .jpg, .jpeg, .svg" class="custom-file-input" name="image" id="image" required>
                                                    <label class="custom-file-label" for="image">Select file</label>
                                                </div>
                                                <?php if($errors->has('image')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __('Add Coupon')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/coupon/addGroceryCoupon.blade.php ENDPATH**/ ?>