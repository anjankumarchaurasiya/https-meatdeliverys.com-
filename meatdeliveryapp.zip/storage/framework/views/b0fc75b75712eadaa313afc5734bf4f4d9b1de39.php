

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Delivery Boys') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
        <div class="row">
            <div class="col">
                    <div class="card form-card shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Delivery Boys')); ?></h3>
                                </div>
                                <div class="col-4 text-right">
                                    <a href="<?php echo e(url('Delivery-guy/create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add Delivery Boy')); ?></a>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <?php if(count($users)>0): ?>       
                                <table class="table align-items-center table-flush">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col"><?php echo e(__('#')); ?></th>
                                            <th scope="col"><?php echo e(__('Image')); ?></th>
                                            <th scope="col"><?php echo e(__('Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Email')); ?></th>
                                            <th scope="col"><?php echo e(__('Phone')); ?></th>    
                                            <th scope="col"><?php echo e(__('Status')); ?></th>
                                            <th scope="col"><?php echo e(__('Radius')); ?></th>
                                            <th scope="col"><?php echo e(__('Role')); ?></th>
                                            <th scope="col"><?php echo e(__('Action')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><img class="avatar avatar-lg" src="<?php echo e(url('images/upload/'.$user->image)); ?>"></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td>
                                                    <a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a>
                                                </td>
                                                <td><?php echo e($user->phone); ?></td>                                               
                                                <td>
                                                    <span class="badge badge-dot mr-4">
                                                        <i class="<?php echo e($user->status==0?'bg-success': 'bg-danger'); ?>"></i>
                                                        <span class="status"><?php echo e($user->status==0?'Active': 'Block'); ?></span>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if($user->driver_radius==null): ?>
                                                        Not Assign
                                                    <?php else: ?> 
                                                    <?php echo e($user->driver_radius.' Km'); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><span class="badge border-1">Delivery Boy</span></td>
                                                <td>
                                                    <div class="dropdown">
                                                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <i class="fas fa-ellipsis-v"></i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                            <?php if($user->driver_radius==null): ?>                                                        
                                                            <a class="dropdown-item open-assign-driver" data-id="<?php echo e($user->id); ?>" data-toggle="modal" data-target="#assignRadius"><?php echo e(__('Assign area')); ?></a>
                                                            <?php endif; ?>
                                                            <a class="dropdown-item" href="<?php echo e(url('Driver/edit/'.$user->id)); ?>"><?php echo e(__('Edit')); ?></a>
                                                            <a class="dropdown-item" href="#" onclick="deleteData('Customer','<?php echo e($user->id); ?>');" ><?php echo e(__('Delete')); ?></a>
                                                          
                                                        </div>
                                                    </div> 
                                                  
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?> 
                                <div class="empty-state text-center pb-3">
                                    <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:35%;height:220px;">
                                    <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__("Nothing!!")); ?></h2>
                                    <p style="font-weight:600;"><?php echo e(__("Your Collection list is empty....")); ?></p>
                            <?php endif; ?>                                
                            </div>
                    </div>
            </div>
        </div>
       
    </div>



    <div class="modal fade" id="assignRadius" tabindex="-1" role="dialog" aria-labelledby="assignRadiusLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="assignRadiusLabel"><?php echo e(__('Assign Radius to Driver')); ?></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body bg-secondary">
                <form method="post" action="<?php echo e(url('assignRadius')); ?>">
                        <?php echo csrf_field(); ?>                        
                            <div class="form-group<?php echo e($errors->has('driver_radius') ? ' has-danger' : ''); ?>">                                            
                                <label class="form-control-label" for="input-driver_radius"><?php echo e(__('Radius (KM)')); ?></label>
                                <input type="number" name="driver_radius" id="input-driver_radius" class="form-control form-control-alternative<?php echo e($errors->has('driver_radius') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Radius')); ?>" value="" required autofocus>
                                <?php if($errors->has('driver_radius')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('driver_radius')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="driver_id" id="driver_id" class="form-control">
                                                     
                            <div class="form-group text-right"> 
                                
                                <button  type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>   
                            </div>                                              
                   </form>
                </div>
                
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Delivery Boys')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/mainAdmin/users/deliveryGuys.blade.php ENDPATH**/ ?>