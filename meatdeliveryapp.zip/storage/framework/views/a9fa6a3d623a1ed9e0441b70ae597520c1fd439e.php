
<?php echo $content; ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/mailMessage.blade.php ENDPATH**/ ?>