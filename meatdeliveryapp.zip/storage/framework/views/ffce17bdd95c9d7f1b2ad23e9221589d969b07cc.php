

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Add Location') ,
        'headerData' => __('Locations') ,
        'url' => 'Location' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Add Location')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('Location')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(url('Location')); ?>" autocomplete="off" >
                                    <?php echo csrf_field(); ?>
                                    
                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Location Detail')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                                    <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e(old('name')); ?>" required autofocus>
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-phone"><?php echo e(__('Phone')); ?></label>
                                                    <input type="text" name="phone" id="input-phone" class="form-control form-control-alternative<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e(old('phone')); ?>" required>
                                                    <?php if($errors->has('phone')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-address"><?php echo e(__('Address')); ?></label>
                                            <textarea name="address" id="input-address" class="form-control form-control-alternative<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Address')); ?>" required ><?php echo e(old('address')); ?></textarea>
                                            <?php if($errors->has('address')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('address')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                      
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('latitude') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-latitude"><?php echo e(__('Latitude')); ?></label>
                                                    <input type="text" name="latitude" id="input-latitude" class="form-control form-control-alternative<?php echo e($errors->has('latitude') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Latitude')); ?>" value="<?php echo e(old('latitude')); ?>" required>
                                                    <?php if($errors->has('latitude')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('latitude')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('longitude') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-longitude"><?php echo e(__('Longitude')); ?></label>
                                                    <input type="text" name="longitude" id="input-longitude" class="form-control form-control-alternative<?php echo e($errors->has('longitude') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Longitude')); ?>" value="<?php echo e(old('longitude')); ?>" required>
                                                    <?php if($errors->has('longitude')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('longitude')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('radius') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-radius"><?php echo e(__('Radius')); ?></label>
                                            <input type="text" name="radius" id="input-radius" class="form-control form-control-alternative<?php echo e($errors->has('radius') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Radius')); ?>" value="<?php echo e(old('radius')); ?>" required>
                                            <?php if($errors->has('radius')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('radius')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-description"><?php echo e(__('Description')); ?></label>
                                            <textarea name="description" id="input-description" class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Description')); ?>" required ><?php echo e(old('description')); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    
                                        <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                            <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                <option value="">Select Status</option>
                                                <option value="0" <?php echo e(old('status')=="0" ? 'Selected' : ''); ?>>Active</option>
                                                <option value="1" <?php echo e(old('status')=="1" ? 'Selected' : ''); ?>>Deactive</option>
                                            </select>
        
                                            <?php if($errors->has('status')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('status')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    
                                        <div class="form-group<?php echo e($errors->has('popular') ? ' has-danger' : ''); ?>">                                            
                                                <div class="row">
                                                    <div class="col-2"> <label class="form-control-label"><?php echo e(__('Is Popular')); ?>?</label></div>
                                                    <div class="col-10">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" value="1" name="popular" id="popular">
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                </div>
                                        </div>
        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Add Location')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/mainAdmin/location/addLocation.blade.php ENDPATH**/ ?>