
<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"> <?php echo e(__('Home')); ?> </a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/all-categories')); ?>"> <?php echo e(__('Categories')); ?> </a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('category/'.$data['category']->id.'/'.Str::slug($data['category']->name))); ?>"> <?php echo e($data['category']['name']); ?> </a></li>
                            <li class="breadcrumb-item active" aria-current="page"> <?php echo e($product->name); ?> </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="all-product-grid">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="product-dt-view">
                        <div class="row">
                            <div class="col-lg-4 col-md-4">
                                <?php
                                    $imgs = null;
                                    if($product->gallery != "" || $product->gallery != null){
                                        $imgs = explode(", ",$product->gallery);
                                    }
                                ?>
                                <div id="sync1" class="owl-carousel owl-theme">
                                    <div class="item">
                                        <img src="<?php echo e($product->imagePath . $product->image); ?>" alt="">
                                    </div>
                                    <?php if($imgs != null): ?>
                                        <?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">
                                                <img src="<?php echo e($product->imagePath . $item); ?>" alt="">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <div id="sync2" class="owl-carousel owl-theme">
                                    <div class="item">
                                        <img src="<?php echo e($product->imagePath . $product->image); ?>" alt="">
                                    </div>
                                    <?php if($imgs != null): ?>
                                        <?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="item">
                                                <img src="<?php echo e($product->imagePath . $item); ?>" alt="">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <input type="hidden" id="product_id" name="product_id" value="<?php echo e($product->id); ?>">
                            <div class="col-lg-8 col-md-8">
                                <div class="product-dt-right">
                                    <h2> <?php echo e($product->name); ?> </h2>
                                    <div class="no-stock">
                                        <?php if($product->stock <= 0): ?>
                                            <p class="stock-qty"><?php echo e(__('Not Available')); ?><span><?php echo e(__('(Out Of Stock)')); ?></span></p>
                                        <?php else: ?>
                                            <p class="stock-qty"><?php echo e(__('Available')); ?><span><?php echo e(__('(Instock)')); ?></span></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-radio">
                                        <ul class="product-now">
                                            <?php $__currentLoopData = json_decode($product->detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <input type="radio" id="<?php echo e($key); ?>" name="detail" class="item-detail" <?php echo e($key == 0? 'checked':''); ?>>
                                                    <label for="<?php echo e($key); ?>"> <?php echo e($item->qty); ?><?php echo e($item->unit); ?> </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <p class="pp-descp">
                                        <?php echo e($product->description); ?>

                                    </p>
                                    <div class="product-group-dt">
                                        <ul id="product-price">
                                            <li class="li-sell-price"><div class="main-price color-discount"> <?php echo e(__('Discount Price')); ?> <span id="price"> <?php echo e($data['currency']); ?><span class="product-sell_price"><?php echo e($product->sell_price); ?></span></span></div></li>
                                            <li class="li-fake-price"><div class="main-price mrp-price"> <?php echo e(__('MRP Price')); ?> <span id="fake_price"> <?php echo e($data['currency']); ?><span class="product-fake_price"><?php echo e($product->fake_price); ?></span> </span></div></li>
                                        </ul>
                                        <ul class="gty-wish-share">
                                            <li>
                                                <div class="qty-product">
                                                    <div class="quantity buttons_added">
                                                        <input type="hidden" value="0" name="item-index-id" class="item-index-id">
                                                        <input type="button" value="-" class="minus minus-btn">
                                                        <input type="number" step="1" name="quantity" min="1" value="<?php echo e($product->qtyCount); ?>" class="input-text item-qty qty text qtyOf-<?php echo e($product->id); ?>">
                                                        <input type="button" value="+" class="plus plus-btn">
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <span class="like-icon save-icon like-<?php echo e($product->id); ?> <?php echo e($product->isWishlist == 1? 'liked':''); ?>" data-id="<?php echo e($product->id); ?>" title="wishlist"></span>
                                            </li>
                                        </ul>
                                        <ul class="ordr-crt-share">
                                            <li>
                                                <button class="add-cart-btn single-page-product add-to-cart hover-btn <?php echo e($product['isCart'] == 1? 'remove-cart':'add-cart'); ?> " data-id="<?php echo e($product->id); ?>">
                                                    <i class="uil uil-shopping-cart-alt"></i>
                                                    <span class="text-cart"> <?php echo e($product['isCart'] == 1? 'Remove from Cart':'Add to Cart'); ?> </span>
                                                </button>
                                            </li>
                                            <?php if(Auth::check()): ?>
                                                <?php $url = url('/checkout') ?>
                                            <?php else: ?>
                                                <?php $url = url('/signin') ?>
                                            <?php endif; ?>
                                            <li><button onclick="location.href =  '<?php echo e($url); ?>';" class="order-btn hover-btn"> <?php echo e(__('Order Now')); ?> </button></li>
                                        </ul>
                                    </div>
                                    <div class="pdp-details">
                                        <ul>
                                            <li>
                                                <div class="pdp-group-dt">
                                                    <div class="pdp-icon"><i class="uil uil-usd-circle"></i></div>
                                                    <div class="pdp-text-dt">
                                                        <span> <?php echo e(__('Lowest Price Guaranteed')); ?> </span>
                                                        <p> <?php echo e(__('Get difference refunded if you find it cheaper anywhere else.')); ?> </p>
                                                    </div>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="pdp-group-dt">
                                                    <div class="pdp-icon"><i class="uil uil-cloud-redo"></i></div>
                                                    <div class="pdp-text-dt">
                                                        <span> <?php echo e(__('Easy Returns & Refunds')); ?> </span>
                                                        <p> <?php echo e(__('Return products at doorstep and get refund in seconds.')); ?> </p>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-12">
                    <div class="pdpt-bg">
                        <div class="pdpt-title">
                            <h4> <?php echo e(__('More Like This')); ?> </h4>
                        </div>
                        <div class="pdpt-body scrollstyle_4">
                            <?php if(count($data['like_this']) > 0): ?>
                                <?php $__currentLoopData = $data['like_this']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="cart-item border_radius">
                                        <a href="<?php echo e(url('product/'.$item->id .'/'.Str::slug($item->name))); ?>" class="cart-product-img">
                                            <img src="<?php echo e($item->imagePath . $item->image); ?>" alt="">
                                            <div class="offer-badge"><?php echo e($item->off); ?>% <?php echo e(__('OFF')); ?></div>
                                        </a>
                                        <div class="cart-text">
                                            <h4> <?php echo e($item->name); ?> </h4>
                                           
                                            <div class="product-price text-left">
                                                <?php echo e($data['currency']); ?><span class="sell_price"><?php echo e($item->sell_price); ?></span>
                                                <span class="line-through"><?php echo e($data['currency']); ?><span class="fake_price"><?php echo e($item->fake_price); ?></span></span>
                                            </div>
                                            <div class="qty-group">
                                                <div class="quantity buttons_added">
                                                    <input type="button" value="-" class="minus minus-btn">
                                                    <input type="number" step="1" name="quantity" min="1" value="<?php echo e($item['qtyCount']); ?>" class="input-text qty text qtyOf-<?php echo e($item['id']); ?>">
                                                    <input type="button" value="+" class="plus plus-btn">
                                                </div>
												<span class="cart-icon single-page add-to-cart cart-<?php echo e($item['id']); ?> <?php echo e($item['isCart'] == 1? 'pri-color':''); ?>" data-id="<?php echo e($item['id']); ?>"><i class="uil uil-shopping-cart-alt"></i></span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="how-order-steps">
                                    <div class="how-order-icon">
                                        <i class="uil uil-shopping-basket"></i>
                                    </div>
                                    <h4> <?php echo e(__('No Product Available')); ?> </h4>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-12">
                    <div class="pdpt-bg">
                        <div class="pdpt-title">
                            <h4> <?php echo e(__('Product Details')); ?> </h4>
                        </div>
                        <?php echo html_entity_decode($product->detail_desc); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Featured Products Start -->
    <div class="section145">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="main-title-tt">
                        <div class="main-title-left">
                            <span><?php echo e(__('For You')); ?></span>
                            <h2><?php echo e(__('Top Featured Products')); ?></h2>
                        </div>
                        <a href="<?php echo e(url('/featured-products')); ?>" class="see-more-btn"><?php echo e(__('See All')); ?></a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel featured-slider owl-theme">
                        <?php $__currentLoopData = $data['top_featured']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                               <?php echo $__env->make('frontend.model.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Featured Products End -->
</div>
<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/single-product.blade.php ENDPATH**/ ?>