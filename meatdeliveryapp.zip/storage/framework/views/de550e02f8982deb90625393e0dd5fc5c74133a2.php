

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Edit Banner') ,
        'headerData' => __('Banner') ,
        'url' => 'Banner' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Edit Banner')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('Banner')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(url('Banner/'.$data->id)); ?>" autocomplete="off" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Banner Detail')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="form-group<?php echo e($errors->has('title1') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-title1"><?php echo e(__('Title 1')); ?></label>
                                            <input type="text" name="title1" id="input-title1" class="form-control form-control-alternative<?php echo e($errors->has('title1') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Title 1')); ?>" value="<?php echo e($data->title1); ?>" required autofocus>
                                            <?php if($errors->has('title1')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('title1')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('title2') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-title2"><?php echo e(__('Title 2')); ?></label>
                                            <input type="text" name="title2" id="input-title2" class="form-control form-control-alternative<?php echo e($errors->has('title2') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Title 2')); ?>" value="<?php echo e($data->title2); ?>" required>
                                            <?php if($errors->has('title2')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('title2')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('url') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-url"><?php echo e(__('URL')); ?></label>
                                            <input type="url" name="url" id="input-url" class="form-control form-control-alternative<?php echo e($errors->has('url') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('URL')); ?>" value="<?php echo e($data->url); ?>" required>
                                            <?php if($errors->has('url')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('url')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('off') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-off"><?php echo e(__('Off')); ?></label>
                                            <input type="text" name="off" id="input-off" class="form-control form-control-alternative<?php echo e($errors->has('off') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Off')); ?>" value="<?php echo e($data->off); ?>" required>
                                            <?php if($errors->has('off')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('off')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-10">
                                                <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                    <div class="custom-file">
                                                        <input type="file"  accept=".png, .jpg, .jpeg, .svg" class="custom-file-input read-image" name="image" id="image">
                                                        <label class="custom-file-label" for="image">Select file</label>
                                                    </div>
                                                    <?php if($errors->has('image')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('image')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <img class=" avatar-lg round-5 view-image" style="width: 100%;height: 90px;" src="<?php echo e(url('images/upload/'.$data->image)); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                            <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                <option value="">Select Status</option>
                                                <option value="0" <?php echo e($data->status=="0" ? 'Selected' : ''); ?>>Active</option>
                                                <option value="1" <?php echo e($data->status=="1" ? 'Selected' : ''); ?>>Deactive</option>
                                            </select>
        
                                            <?php if($errors->has('status')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('status')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>                                                                       
        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Edit Banner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/mainAdmin/banner/editBanner.blade.php ENDPATH**/ ?>