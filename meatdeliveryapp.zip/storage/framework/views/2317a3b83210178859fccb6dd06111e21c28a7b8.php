<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Edit Grocery Shop') ,
        'headerData' => __('Grocery Shops') ,
        'url' => 'GroceryShop' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Edit Grocery Shop')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('GroceryShop')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" id="edit-groceyshop" action="<?php echo e(url('GroceryShop/'.$data->id)); ?>" autocomplete="off" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Edit Grocery Shop Detail')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="row">
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-name"><?php echo e(__('Shop Name')); ?></label>
                                                    <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Shop Name')); ?>" value="<?php echo e($data->name); ?>" required autofocus>
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-address"><?php echo e(__('Shop Address')); ?></label>
                                                    <input type="text" name="address" id="input-address" class="form-control form-control-alternative<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Shop Address')); ?>" value="<?php echo e($data->address); ?>" required >
                                                    <?php if($errors->has('address')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group<?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                                        <label class="form-control-label" for="input-description"><?php echo e(__('Description')); ?></label>
                                                        <textarea name="description" id="input-description" class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Description')); ?>" required><?php echo e($data->description); ?></textarea>
                                                        <?php if($errors->has('description')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('description')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('latitude') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-latitude"><?php echo e(__('Latitude')); ?></label>
                                                    <input type="text" name="latitude" id="input-latitude" class="form-control form-control-alternative<?php echo e($errors->has('latitude') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Latitude')); ?>" value="<?php echo e($data->latitude); ?>" required >
                                                    <?php if($errors->has('latitude')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('latitude')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('longitude') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-longitude"><?php echo e(__('Longitude')); ?></label>
                                                    <input type="text" name="longitude" id="input-longitude" class="form-control form-control-alternative<?php echo e($errors->has('longitude') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Longitude')); ?>" value="<?php echo e($data->longitude); ?>" required >
                                                    <?php if($errors->has('longitude')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('longitude')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('location') ? ' has-danger' : ''); ?>">
                                                        <label class="form-control-label" for="input-location"><?php echo e(__('Location')); ?></label>
                                                        <Select name="location" id="input-location" class="form-control form-control-alternative<?php echo e($errors->has('location') ? ' is-invalid' : ''); ?>"  required>
                                                            <option value=""><?php echo e(__('Select Location')); ?></option>
                                                            <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>" <?php echo e($data->location==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>

                                                        <?php if($errors->has('location')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('location')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('website') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-website"><?php echo e(__('Website')); ?></label>
                                                    <input type="text" name="website" id="input-website" class="form-control form-control-alternative<?php echo e($errors->has('website') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Website')); ?>" value="<?php echo e($data->website); ?>" >
                                                    <?php if($errors->has('website')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('website')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-phone"><?php echo e(__('Phone')); ?></label>
                                                    <input type="text" name="phone" id="input-phone" class="form-control form-control-alternative<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e($data->phone); ?>" required >
                                                    <?php if($errors->has('phone')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <input type='hidden' id="shop_category" name="shop_category" value="<?php echo e($data->category_id); ?>">
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('category_id') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-category_id"><?php echo e(__('Category')); ?></label>
                                                    <Select name="category_id[]" id="input-category_id" multiple="multiple" class="form-control select2 select2-multiple form-control-alternative<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>"  required>
                                                        <option value=""><?php echo e(__('Select Category')); ?></option>
                                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" <?php echo e($data->category_id==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>    
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                       
                                                    </select>

                                                    <?php if($errors->has('category_id')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('category_id')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('delivery_type') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-delivery_type"><?php echo e(__('Delivery Type')); ?></label>
                                                    <Select name="delivery_type" id="input-delivery_type" class="form-control form-control-alternative<?php echo e($errors->has('delivery_type') ? ' is-invalid' : ''); ?>"  required>
                                                        <option value=""><?php echo e(__('Select Delivery Type')); ?></option>
                                                        <option value="Home" <?php echo e($data->delivery_type=="Home" ? 'Selected' : ''); ?>>Delivery at Home</option>
                                                        <option value="Shop" <?php echo e($data->delivery_type=="Shop" ? 'Selected' : ''); ?>>Arrive product at shop</option>
                                                        <option value="Both" <?php echo e($data->delivery_type=="Both" ? 'Selected' : ''); ?>>Both</option>
                                                    </select>
        
                                                    <?php if($errors->has('delivery_type')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('delivery_type')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('radius') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-radius"><?php echo e(__('Shop Radius')); ?></label>
                                                    <input type="number" name="radius" id="input-radius" min="0" class="form-control form-control-alternative<?php echo e($errors->has('radius') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Shop Radius')); ?>" value="<?php echo e($data->radius); ?>" required>
                                                    <?php if($errors->has('radius')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('radius')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                                    <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                        <option value=""><?php echo e(__('Select Status')); ?></option>
                                                        <option value="0" <?php echo e($data->status=="0" ? 'Selected' : ''); ?>>Active</option>
                                                        <option value="1" <?php echo e($data->status=="1" ? 'Selected' : ''); ?>>Deactive</option>
                                                    </select>

                                                    <?php if($errors->has('status')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('status')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('open_time') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-open_time"><?php echo e(__('Open Time')); ?></label>
                                                    <input type="time" name="open_time" id="input-open_time" class="form-control form-control-alternative<?php echo e($errors->has('open_time') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Open Time')); ?>" value="<?php echo e($data->open_time); ?>"  >
                                                    <?php if($errors->has('open_time')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('open_time')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group<?php echo e($errors->has('close_time') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-close_time"><?php echo e(__('Close Time')); ?></label>
                                                    <input type="time" name="close_time" id="input-close_time" class="form-control form-control-alternative<?php echo e($errors->has('close_time') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Close Time')); ?>" value="<?php echo e($data->close_time); ?>" >
                                                    <?php if($errors->has('close_time')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('close_time')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-10">
                                                <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-image"><?php echo e(__('Shop Logo')); ?></label>
                                                    <div class="custom-file">
                                                        <input type="file"  accept=".png, .jpg, .jpeg, .svg" class="custom-file-input read-image" name="image" id="image">
                                                        <label class="custom-file-label" for="image"><?php echo e(__('Select file')); ?></label>
                                                    </div>
                                                    <?php if($errors->has('image')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('image')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <img class=" avatar-lg round-5 view-image" style="width: 100%;height: 90px;" src="<?php echo e(url('images/upload/'.$data->image)); ?>">
                                            </div>
                                            <div class="col-10">
                                                <div class="form-group<?php echo e($errors->has('cover_image') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-cover_image"><?php echo e(__('Cover Image')); ?></label>
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input read-cover-image" name="cover_image" id="cover_image">
                                                        <label class="custom-file-label" for="cover_image"><?php echo e(__('Select file')); ?></label>
                                                    </div>
                                                    <?php if($errors->has('cover_image')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('cover_image')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <img class=" avatar-lg round-5 view-cover-image" style="width: 100%;height: 90px;" src="<?php echo e(url('images/upload/'.$data->cover_image)); ?>">
                                            </div>
                                        </div>


                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __('Edit Shop')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/GroceryShop/editGroceryShop.blade.php ENDPATH**/ ?>