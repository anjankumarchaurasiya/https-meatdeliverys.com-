
<?php $__env->startSection('title', __('Forgot Password')); ?>

<?php $__env->startSection('content'); ?>
<?php
    $company = \App\CompanySetting::first(['logo','phone','logo_dark']);
?>
<div class="sign-inup">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="sign-form">
                    <div class="sign-inner">
                        <div class="sign-logo" id="logo">
                            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('images/upload/'.$company->responsive_logo)); ?>" alt=""></a>
                            <a href="<?php echo e(url('/')); ?>"><img class="logo-inverse" src="<?php echo e(url('images/upload/'.$company->logo_dark)); ?>" alt=""></a>
                        </div>
                        <div class="form-dt">
                            <div class="form-inpts checout-address-step">
                                <form action="forgot-password" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-title"><h6> <?php echo e(__('Get New Password')); ?> </h6></div>
                                    <div class="form-group pos_rel">
                                        <input id="email" name="email" type="email" placeholder="Your Email Address" class="form-control lgn_input" required="">
                                        <i class="uil uil-envelope lgn_icon"></i>
                                    </div>
                                    <button class="login-btn hover-btn" type="submit"> <?php echo e(__("Submit")); ?> </button>
                                </form>
                                <?php if($message = Session::get('error_msg')): ?>
                                    <h4 class="text-center text-danger"><?php echo e($message); ?></h4>
                                <?php endif; ?>
                                <?php if($message = Session::get('success_msg')): ?>
                                    <h4 class="text-center text-success"><?php echo e($message); ?></h4>
                                <?php endif; ?>
                            </div>
                            <div class="signup-link">
                                <p><?php echo e(__('Go Back')); ?> - <a href="<?php echo e(url('/signin')); ?>"><?php echo e(__('Sign In Now')); ?></a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="copyright-text text-center mt-3">
                    <i class="uil uil-copyright"></i> <?php echo e(__('Copyright')); ?> <?php echo date('Y'); ?> <b > <?php echo e($company->name); ?> </b>. <?php echo e(__('All rights reserved')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.loginMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/forgotPassword.blade.php ENDPATH**/ ?>