
<?php $__env->startSection('title', __('Sign-in')); ?>

<?php $__env->startSection('content'); ?>
<?php
    $company = \App\CompanySetting::first(['logo','name','logo_dark']);
?>
    <div class="sign-inup">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="sign-form">
                        <div class="sign-inner">
                            <div class="sign-logo" id="logo">
                                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('images/upload/'.$company->logo)); ?>" alt=""></a>
                                <a href="<?php echo e(url('/')); ?>"><img class="logo-inverse" src="<?php echo e(url('images/upload/'.$company->logo_dark)); ?>" alt=""></a>
                            </div>
                            <div class="form-dt">
                                <div class="form-inpts checout-address-step">
                                    <form action="<?php echo e(url('/signin')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-title"><h6><?php echo e(__('Sign In')); ?></h6></div>
                                        <div class="form-group pos_rel">
                                            <input id="email" name="email" type="text" placeholder="<?php echo e(__('Enter Email Address')); ?>" class="form-control lgn_input">
                                            <i class="uil uil-mobile-android-alt lgn_icon"></i>
                                        </div>
                                        <div class="form-group pos_rel">
                                            <input id="password" name="password" type="password" placeholder="<?php echo e(__('Enter Password')); ?>" class="form-control lgn_input">
                                            <i class="uil uil-padlock lgn_icon"></i>
                                        </div>
                                        <?php if($errors->any()): ?>
                                            <h4 class="text-center text-danger"><?php echo e($errors->first()); ?></h4>
                                        <?php endif; ?>
                                        <?php if($message = Session::get('error')): ?>
                                            <h4 class="text-center text-danger"><?php echo e($message); ?></h4>
                                        <?php endif; ?>
                                        <?php if($message = Session::get('msg')): ?>
                                            <h4 class="text-center text-success"><?php echo e($message); ?></h4>
                                        <?php endif; ?>
                                        <button class="login-btn hover-btn" type="submit"><?php echo e(__('Sign In Now')); ?></button>
                                    </form>
                                </div>
                                <div class="password-forgor">
                                    <a href="<?php echo e(url('/forgot-password')); ?>"><?php echo e(__('Forgot Password')); ?>?</a>
                                </div>
                                <div class="signup-link">
                                    <p><?php echo e(__("Don't have an account?")); ?> - <a href="<?php echo e(url('/signup')); ?>"><?php echo e(__('Sign Up Now')); ?></a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="copyright-text text-center mt-3">
                        <i class="uil uil-copyright"></i> <?php echo e(__('Copyright')); ?> <?php echo date('Y'); ?> <b > <?php echo e($company->name); ?> </b>. <?php echo e(__('All rights reserved')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.loginMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/signin.blade.php ENDPATH**/ ?>