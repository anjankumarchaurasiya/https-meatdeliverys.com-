

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Grocery Orders') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
        <div class="row">
            <div class="col">
                    <div class="card form-card shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Grocery Orders')); ?></h3>
                                </div>                               
                            </div>
                        </div>

                        <div class="table-responsive">
                               
                                <?php    $total_payment = 0;  ?>  
                              
                                

                                <table class="table data-table align-items-center table-flush" id="reports">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col"><?php echo e(__('#')); ?></th>
                                            <th scope="col"><?php echo e(__('Order ID')); ?></th>
                                            <th scope="col"><?php echo e(__('Customer')); ?></th>
                                            <th scope="col"><?php echo e(__('Location Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Date')); ?></th>                                           
                                            <th scope="col"><?php echo e(__('Payment Gateway')); ?></th>
                                            <th scope="col"><?php echo e(__('Order Status')); ?></th>
                                            <th scope="col"><?php echo e(__('Payment')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                            <?php $total_payment = $total_payment + $item->payment; ?>
                                           
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($item->order_no); ?></td>
                                                <td><?php echo e($item->customer->name); ?></td>
                                                <td><?php echo e($item->location->name); ?></td>
                                                <td><?php echo e($item->date); ?> </td>                                               
                                                <td><?php echo e($item->payment_type); ?> </td>
                                                <td><?php echo e($item->order_status); ?> </td>
                                                <td><?php echo e($currency.$item->payment); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <thead class="footer-head">
                                        <tr >
                                            <th></th> 
                                            <th></th>
                                            <th></th>   
                                            <th></th>                                        
                                            <th></th>   
                                            <th></th>
                                            <th><?php echo e(__('Total Income')); ?> </th>
                                            <th><?php echo e($currency.$total_payment); ?></th>
                                           
                                        </tr>
                                    </thead>
                                </table>
                                                      
                            </div>
                    </div>
            </div>
        </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Orders')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/GroceryOrder/revenueReport.blade.php ENDPATH**/ ?>