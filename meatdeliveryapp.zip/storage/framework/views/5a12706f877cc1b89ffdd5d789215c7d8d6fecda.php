
	<!-- Category Model Start-->
	<div id="category_model" class="header-cate-model main-gambo-model modal fade" tabindex="-1" role="dialog" aria-modal="false">
        <div class="modal-dialog category-area" role="document">
            <div class="category-area-inner">
                <div class="modal-header">
                    <button type="button" class="close btn-close" data-dismiss="modal" aria-label="Close">
						<i class="uil uil-multiply"></i>
                    </button>
                </div>
                <div class="category-model-content modal-content"> 
					<div class="cate-header">
						<h4> <?php echo e(__('Select Category')); ?> </h4>
					</div>
					<?php
						$categories = \App\GroceryCategory::where('status',0)->get();
					?>
					
					<?php if(count($categories) >= 1): ?>
						<ul class="category-by-cat">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<a href="<?php echo e(url('category/'.$item->id.'/'.Str::slug($item->name))); ?>" class="single-cat-item">
										<div class="icon">
											<img src="<?php echo e($item->imagePath . $item->image); ?>" alt="">
										</div>
										<div class="text"> <?php echo e($item->name); ?> </div>
									</a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
						<a href="<?php echo e(url('/all-categories')); ?>" class="morecate-btn"><i class="uil uil-apps"></i> <?php echo e(__('More Categories')); ?> </a>
					<?php else: ?>
						<div class="col-lg-12 col-md-12">
							<div class="how-order-steps">
								<div class="how-order-icon">
									<i class="uil uil-apps"></i>
								</div>
								<h4> <?php echo e(__('No Category Available')); ?> </h4>
							</div>
						</div>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
	<!-- Category Model End--><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/model/category.blade.php ENDPATH**/ ?>