

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Users') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
        <div class="row">
            <div class="col">
                    <div class="card form-card shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Users')); ?></h3>
                                </div>
                              
                            </div>
                        </div>

                        <div class="table-responsive">
                           
                            
                                <table class="table data-table align-items-center table-flush" id="reports">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col"><?php echo e(__('#')); ?></th>
                                            <th scope="col"><?php echo e(__('Image')); ?></th>
                                            <th scope="col"><?php echo e(__('Name')); ?></th>
                                            <th scope="col"><?php echo e(__('Email')); ?></th>
                                            <th scope="col"><?php echo e(__('Phone')); ?></th>                                            
                                            <th scope="col"><?php echo e(__('Status')); ?></th>                                             
                                            <th scope="col"><?php echo e(__('Registered at')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><img class="avatar avatar-lg" src="<?php echo e(url('images/upload/'.$user->image)); ?>"></td>
                                                <td><?php echo e($user->name); ?></td>
                                                <td>
                                                    <a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a>
                                                </td>
                                                <td><?php echo e($user->phone); ?></td>                                                
                                                <td>
                                                    <span class="badge badge-dot mr-4">
                                                        <i class="<?php echo e($user->status==0?'bg-success': 'bg-danger'); ?>"></i>
                                                        <span class="status"><?php echo e($user->status==0?'Active': 'Block'); ?></span>
                                                    </span>
                                                </td>                                               
                                                
                                                <td><?php echo e($user->created_at->format('Y-m-d')); ?></td> 
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>                                                   
                            </div>
                    </div>
            </div>
        </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Users')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/mainAdmin/users/userReport.blade.php ENDPATH**/ ?>