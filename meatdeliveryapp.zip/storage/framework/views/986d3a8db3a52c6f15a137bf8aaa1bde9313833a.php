

<?php $__env->startSection('content_setting'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Settings') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <div class="container-fluid mt--7">
           
        <div class="row">
            <div class="col">
                    <div class="card bg-secondary form-card shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Settings')); ?></h3>
                                </div>                            
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3" style="border-right: 1px solid #ddd;">
                                  
                                    <ul class="nav nav-tabs tabs-left sideways border-0">  
                                        <li><a href="#general-v" class="active" data-toggle="tab"> <i class="ni ni-settings-gear-65 mr-2"></i><?php echo e(__("General")); ?></a></li>
                                        <li><a href="#payment-v" class="" data-toggle="tab"><i class="far fa-credit-card mr-2"></i><?php echo e(__("Payment Gateway")); ?></a></li>
                                        <li><a href="#language-v" class="" data-toggle="tab"><i class="fas fa-language mr-2"></i><?php echo e(__("Language Setting")); ?></a></li>
                                        <li><a href="#verification-v" class="" data-toggle="tab"><i class="fas fa-user-check mr-2"></i><?php echo e(__("User Verification")); ?></a></li>
                                        
                                        <li><a href="#notification-va" class="" data-toggle="tab"><i class="far fa-bell mr-2"></i><?php echo e(__("Push Notification")); ?></a></li>
                                        <li><a href="#web-notification-v" class="" data-toggle="tab"><i class="fas fa-bell mr-2"></i><?php echo e(__("Web Notification")); ?></a></li>
                                        <li><a href="#mail-v" class="" data-toggle="tab"><i class="far fa-envelope mr-2"></i><?php echo e(__("Mail")); ?></a></li>
                                        <li><a href="#sms-v" class="" data-toggle="tab"><i class="far fa-comments mr-2"></i><?php echo e(__("SMS Gateway")); ?></a></li>
                                        <li><a href="#map-v" class="" data-toggle="tab"><i class="far fa-map  mr-2"></i><?php echo e(__("Map Setting")); ?></a></li>
                                        
                                        <li><a href="#additional-v" class="" data-toggle="tab"><i class="ni ni-settings mr-2"></i><?php echo e(__("Additional setting")); ?></a></li>                                     
                                         
                                        
                                        
                                        
                                    </ul>
                                </div>
                                <div class="col-9">
                                    <div class="tab-content">
                                        <div class="tab-pane" id="web-notification-v">
                                            <form method="post" action="<?php echo e(url('saveWebNotificationSettings')); ?>" autocomplete="off"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <h6 class="heading-small text-muted mb-4"><?php echo e(__("Web Notification Setting")); ?></h6>
                                                <div>
                                                    <div class="form-group<?php echo e($errors->has('web_notification') ? ' has-danger' : ''); ?>">
                                                        <div class="row">
                                                            <div class="col-3"> <label class="form-control-label"><?php echo e(__('Enable Web Notification')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <label class="custom-toggle">
                                                                    <input type="checkbox" value="1" <?php echo e($setting->web_notification == 1?'checked':''); ?>

                                                                        name="web_notification" id="web_notification">
                                                                    <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                        data-label-on="Yes"></span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row <?php echo e($errors->has('web_onesignal_api_key') ? ' has-danger' : ''); ?>">
                                                        <div class="col-3">
                                                            <label class="form-control-label"
                                                                for="input-web_onesignal_api_key"><?php echo e(__('One Signal Rest Api Key')); ?>:</label>
                                                        </div>
                                                        <div class="col-9">
                                                            <input type="text" name="web_onesignal_api_key" id="input-web_onesignal_api_key"
                                                                class="form-control form-control-alternative<?php echo e($errors->has('web_onesignal_api_key') ? ' is-invalid' : ''); ?>"
                                                                placeholder="<?php echo e(__('One Signal Rest Api Key for Web notification')); ?>"
                                                                value="<?php echo e($setting->web_onesignal_api_key); ?>">
                                                            <?php if($errors->has('web_onesignal_api_key')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('web_onesignal_api_key')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row <?php echo e($errors->has('web_onesignal_auth_key') ? ' has-danger' : ''); ?>">
                                                        <div class="col-3">
                                                            <label class="form-control-label"
                                                                for="input-web_onesignal_auth_key"><?php echo e(__('One Signal Auth Key')); ?>:</label>
                                                        </div>
                                                        <div class="col-9">
                                                            <input type="text" name="web_onesignal_auth_key" id="input-web_onesignal_auth_key"
                                                                class="form-control form-control-alternative<?php echo e($errors->has('web_onesignal_auth_key') ? ' is-invalid' : ''); ?>"
                                                                placeholder="<?php echo e(__('One Signal Auth Key for Web notification')); ?>"
                                                                value="<?php echo e($setting->web_onesignal_auth_key); ?>">
                                                            <?php if($errors->has('web_onesignal_auth_key')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('web_onesignal_auth_key')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row <?php echo e($errors->has('web_onesignal_app_id') ? ' has-danger' : ''); ?>">
                                                        <div class="col-3">
                                                            <label class="form-control-label"
                                                                for="input-web_onesignal_app_id"><?php echo e(__('One Signal AppID')); ?>:</label>
                                                        </div>
                                                        <div class="col-9">
                                                            <input type="text" name="web_onesignal_app_id" id="input-web_onesignal_app_id"
                                                                class="form-control form-control-alternative<?php echo e($errors->has('web_onesignal_app_id') ? ' is-invalid' : ''); ?>"
                                                                placeholder="<?php echo e(__('One Signal AppID for Web notification')); ?>"
                                                                value="<?php echo e($setting->web_onesignal_app_id); ?>">
                                                            <?php if($errors->has('web_onesignal_app_id')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('web_onesignal_app_id')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                        
                                                    <div class="text-right">
                                                        <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                    </div>
                                                </div>
                                            </form>


                                           
                                        </div>
                                        <div class="tab-pane active" id="general-v">
                                                <form method="post" id="company-setting-form" action="<?php echo e(url('adminSetting/'.$companyData->id)); ?>" autocomplete="off"
                                                    enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('put'); ?>
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Company's General Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group row<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="name" id="input-name"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($companyData->name); ?>" required>
                                                                <?php if($errors->has('name')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('address') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-address"><?php echo e(__('Address')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="address" id="input-address"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Address')); ?>" value="<?php echo e($companyData->address); ?>" required>
                                                                <?php if($errors->has('address')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('address')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('phone') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-phone"><?php echo e(__('Phone')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="phone" id="input-phone"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Phone')); ?>" value="<?php echo e($companyData->phone); ?>" required>
                                                                <?php if($errors->has('phone')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('phone')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                                        <div class="form-group row<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="email" name="email" id="input-email"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Email ID')); ?>" value="<?php echo e($companyData->email); ?>" required>
                                                                <?php if($errors->has('email')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('website') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-website"><?php echo e(__('Website')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="website" id="input-website"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('website') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Website')); ?>" value="<?php echo e($companyData->website); ?>">
                                                                <?php if($errors->has('website')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('website')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-3"></div>
                                                            <div class="col-9">
                                                                <img src="<?php echo e(url('images/upload/'.$companyData->logo)); ?>" id="setting-logo"
                                                                    style="width:160px;height:60px;margin-bottom:15px;border-radius:5px;">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('logo') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-logo"><?php echo e(__('Logo')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <div class="custom-file">
                                                                    <input type="file" class="custom-file-input"  accept=".png, .jpg, .jpeg, .svg" name="logo" id="logo">
                                                                    <label class="custom-file-label" for="logo">Select file</label>
                                                                </div>
                                                                <?php if($errors->has('imaglogoe')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('logo')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row">
                                                            <div class="col-3"></div>
                                                            <div class="col-9">
                                                                <img src="<?php echo e(url('images/upload/'.$companyData->logo_dark)); ?>" id="setting-logo_dark"
                                                                    style="width:160px;height:60px;margin-bottom:15px;border-radius:5px;">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('logo_dark') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-logo"><?php echo e(__('Dark Logo')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <div class="custom-file">
                                                                    <input type="file" class="custom-file-input"  accept=".png, .jpg, .jpeg, .svg" name="logo_dark" id="logo_dark">
                                                                    <label class="custom-file-label" for="logo_dark">Select file</label>
                                                                </div>
                                                                <?php if($errors->has('logo_dark')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('logo_dark')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-3"></div>
                                                            <div class="col-9">
                                                                <img src="<?php echo e(url('images/upload/'.$companyData->logo)); ?>" id="setting-responsive_logo"
                                                                    style="width:160px;height:60px;margin-bottom:15px;border-radius:5px;">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('responsive_logo') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-responsive_logo"><?php echo e(__('Responsive Logo')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <div class="custom-file">
                                                                    <input type="file" class="custom-file-input"  accept=".png, .jpg, .jpeg, .svg" name="responsive_logo" id="responsive_logo">
                                                                    <label class="custom-file-label" for="responsive_logo">Select file</label>
                                                                </div>
                                                                <?php if($errors->has('responsive_logo')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('responsive_logo')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-3"></div>
                                                            <div class="col-9">
                                                                <img src="<?php echo e(url('images/upload/'.$companyData->favicon)); ?>" id="setting-favicon"
                                                                    style="width:90px;height:90px;margin-bottom:15px;border-radius:5px;">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row<?php echo e($errors->has('favicon') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-favicon"><?php echo e(__('Favicon Icon')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <div class="custom-file">
                                                                    <input type="file" class="custom-file-input"  accept=".png, .jpg, .jpeg, .svg" name="favicon" id="favicon">
                                                                    <label class="custom-file-label" for="favicon">Select file</label>
                                                                </div>
                                                                <?php if($errors->has('favicon')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('favicon')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row <?php echo e($errors->has('description') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-description"><?php echo e(__('Description')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <textarea name="description" id="input-description"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Description')); ?>"><?php echo e($companyData->description); ?></textarea>
                                                                <?php if($errors->has('description')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>                                                                                    
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>                                          
                                            </div>
                                            <div class="tab-pane" id="payment-v">
                                                <form method="post" action="<?php echo e(url('savePaymentSetting')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Payment Gateway Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group<?php echo e($errors->has('cod') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-4"> <label
                                                                        class="form-control-label"><?php echo e(__('COD (Cash on delivery Payment)')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->cod == 1?'checked':''); ?> name="cod"
                                                                            id="cod">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('whatsapp') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-4"> <label
                                                                        class="form-control-label"><?php echo e(__('Whatsapp')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->whatsapp == 1?'checked':''); ?> name="whatsapp"
                                                                            id="whatsapp">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('stripe') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-4"> <label
                                                                        class="form-control-label"><?php echo e(__('Stripe (Online Payment with Stripe)')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->stripe == 1?'checked':''); ?> name="stripe"
                                                                            id="stripe">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('paypal') ? ' has-danger' : ''); ?>">
                                                            <div class="row ">
                                                                <div class="col-4"> <label
                                                                        class="form-control-label"><?php echo e(__('Paypal (Paypal Express Checkout)')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->paypal == 1?'checked':''); ?> name="paypal"
                                                                            id="paypal">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('razor') ? ' has-danger' : ''); ?>">
                                                            <div class="row pb-1">
                                                                <div class="col-4"> <label class="form-control-label"><?php echo e(__('RazorPay')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->razor == 1?'checked':''); ?> name="razor"
                                                                            id="razor">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('flutterwave') ? ' has-danger' : ''); ?>">
                                                            <div class="row ">
                                                                <div class="col-4"> <label
                                                                        class="form-control-label"><?php echo e(__('Flutterwave')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->flutterwave == 1?'checked':''); ?> name="flutterwave"
                                                                            id="flutterwave">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('paystack') ? ' has-danger' : ''); ?>">
                                                            <div class="row" style="border-bottom:1px solid #ddd;">
                                                                <div class="col-4"> <label
                                                                        class="form-control-label"><?php echo e(__('Paystack')); ?></label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($paymentData->paystack == 1?'checked':''); ?> name="paystack"
                                                                            id="paystack">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        

                                                        <h6 class="heading-small text-muted mb-4" ><?php echo e(__("Stripe")); ?></h6>
                                                        <div class="form-group row<?php echo e($errors->has('stripePublicKey') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-stripePublicKey"><?php echo e(__('Stripe Public Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="stripePublicKey" id="input-stripePublicKey"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('stripePublicKey') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Stripe Public Key')); ?>" value="<?php echo e($paymentData->stripePublicKey); ?>">
                                                                <?php if($errors->has('stripePublicKey')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('stripePublicKey')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('stripeSecretKey') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-stripeSecretKey"><?php echo e(__('Stripe Secret Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="stripeSecretKey" id="input-stripeSecretKey"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('stripeSecretKey') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Stripe Secret Key:')); ?>" value="<?php echo e($paymentData->stripeSecretKey); ?>">
                                                                <?php if($errors->has('stripeSecretKey')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('stripeSecretKey')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        
                                                        <h6 class="heading-small text-muted mb-4 pt-4" style="border-top:1px solid #ddd;"><?php echo e(__("Paypal")); ?></h6>
                                                        <div class="form-group row <?php echo e($errors->has('paypalSendbox') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-paypalSendbox"><?php echo e(__('Paypal Sandbox Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="paypalSendbox" id="input-paypalSendbox"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('paypalSendbox') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Paypal Sandbox Key:')); ?>" value="<?php echo e($paymentData->paypalSendbox); ?>">
                                                                <?php if($errors->has('paypalSendbox')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('paypalSendbox')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('paypalProduction') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-paypalProduction"><?php echo e(__('Paypal Production Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="paypalProduction" id="input-paypalProduction"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('paypalProduction') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Paypal Production Key:')); ?>" value="<?php echo e($paymentData->paypalProduction); ?>">
                                                                <?php if($errors->has('paypalProduction')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('paypalProduction')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <h6 class="heading-small text-muted mb-4 pt-4" style="border-top:1px solid #ddd;"><?php echo e(__("RazorPay")); ?></h6>
                                                        <div class="form-group row<?php echo e($errors->has('razorPublishKey') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-razorPublishKey"><?php echo e(__('Razor Public Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="razorPublishKey" id="input-razorPublishKey"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('razorPublishKey') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('RazorPay Public Key')); ?>" value="<?php echo e($paymentData->razorPublishKey); ?>">
                                                                <?php if($errors->has('razorPublishKey')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('razorPublishKey')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                            
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('razorSecretKey') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-razorSecretKey"><?php echo e(__('RazorPay Secret Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="razorSecretKey" id="input-razorSecretKey"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('razorSecretKey') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('RazorPay Secret Key:')); ?>" value="<?php echo e($paymentData->razorSecretKey); ?>">
                                                                <?php if($errors->has('razorSecretKey')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('razorSecretKey')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                                        <h6 class="heading-small text-muted mb-4 pt-4" style="border-top:1px solid #ddd;"><?php echo e(__("Flutterwave")); ?></h6>
                                                        <div class="form-group row <?php echo e($errors->has('flutterwave_public_key') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-flutterwave_public_key"><?php echo e(__('Flutterwave Public Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="flutterwave_public_key" id="input-flutterwave_public_key"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('flutterwave_public_key') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Flutterwave Public Key')); ?>" value="<?php echo e($paymentData->flutterwave_public_key); ?>">
                                                                <?php if($errors->has('flutterwave_public_key')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('flutterwave_public_key')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <h6 class="heading-small text-muted mb-4 pt-4" style="border-top:1px solid #ddd;"><?php echo e(__("Paystack")); ?></h6>
                                                        <div class="form-group row <?php echo e($errors->has('paystack_public_key') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-paystack_public_key"><?php echo e(__('Paystack Public Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="paystack_public_key" id="input-paystack_public_key"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('paystack_public_key') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Paystack Public Key')); ?>" value="<?php echo e($paymentData->paystack_public_key); ?>">
                                                                <?php if($errors->has('paystack_public_key')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('paystack_public_key')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        
                                            
                                                        
                                            
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            
                                            <div class="tab-pane" id="language-v">
                                                <h6 class="heading-small text-muted mb-4"><?php echo e(__("Language Setting")); ?></h6>
                                                <div class="row">
                                                    <div class="col-3 mb-2 heading-small"><?php echo e(__("Language Name")); ?></div>
                                                    <div class="col-9 mb-2 heading-small"><?php echo e(__("Status")); ?></div>
                                                </div>
                                                <div class="row languages mb-4" style="border-bottom: 1px solid #ddd;">
                                                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-3 mb-2 text-muted"><span><?php echo e($item->name); ?></span></div>
                                                    <div class="col-9 mb-2 text-muted">
                                                        <label class="custom-toggle">
                                                            <input type="checkbox" value="1" class="language-status" <?php echo e($item->status == 1?'checked':''); ?>

                                                                name="status-<?php echo e($item->id); ?>" id="status-<?php echo e($item->id); ?>">
                                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Yes"></span>
                                                        </label>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <a href="<?php echo e(url('downloadSampleJson')); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('Sample .json')); ?></a>
                                                <form method="post" action="<?php echo e(url('Language')); ?>" autocomplete="off" enctype="multipart/form-data" files="true">
                                                    <?php echo csrf_field(); ?>
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Add New Language")); ?></h6>
                                                    <div>
                                                        <div class="form-group row <?php echo e($errors->has('lang_name') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-lang_name"><?php echo e(__('Language Name')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="lang_name" id="input-lang_name"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('lang_name') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Language Name')); ?>">
                                                                <?php if($errors->has('lang_name')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('lang_name')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('file') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-file"><?php echo e(__('Language File')); ?>:<br>(only .json file)</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <div class="custom-file">
                                                                    <input type="file" accept="application/JSON"
                                                                        class="custom-file-input form-control-alternative<?php echo e($errors->has('file') ? ' is-invalid' : ''); ?>"
                                                                        name="file" id="file">
                                                                    <?php if($errors->has('file')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('file')); ?></strong>
                                                                    </span>
                                                                    <?php endif; ?>
                                                                    <label class="custom-file-label" for="file">Select file</label>
                                            
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('icon') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-icon"><?php echo e(__('Language Map icon')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <div class="custom-file">
                                                                    <input type="file"
                                                                        class="custom-file-input form-control-alternative<?php echo e($errors->has('icon') ? ' is-invalid' : ''); ?>"
                                                                        name="icon" id="icon">
                                                                    <?php if($errors->has('icon')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('icon')); ?></strong>
                                                                    </span>
                                                                    <?php endif; ?>
                                                                    <label class="custom-file-label" for="icon">Select file</label>
                                            
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            
                                            <div class="tab-pane" id="verification-v">
                                                <form method="post" action="<?php echo e(url('saveVerificationSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("User Verification Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group<?php echo e($errors->has('user_verify') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-4"> <label class="form-control-label"><?php echo e(__('Verify User')); ?>:</label></div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($setting->user_verify == 1?'checked':''); ?>

                                                                            name="user_verify" id="user_verify">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                            
                                                        <div class="form-group<?php echo e($errors->has('phone_verify') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-4"> <label class="form-control-label"><?php echo e(__('Verification using Phone')); ?>:</label>
                                                                </div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($setting->phone_verify == 1?'checked':''); ?>

                                                                            name="phone_verify" id="phone_verify">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group<?php echo e($errors->has('email_verify') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-4"> <label class="form-control-label"><?php echo e(__('Verification using Email')); ?>:</label>
                                                                </div>
                                                                <div class="col-8">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($setting->email_verify == 1?'checked':''); ?>

                                                                            name="email_verify" id="email_verify">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            
                                            <div class="tab-pane" id="commission-v">
                                                <form method="post" action="<?php echo e(url('saveCommissionSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Commission Setting")); ?></h6>
                                                    <div>
                                                        
                                                    <div class="form-group row <?php echo e($errors->has('commission_per') ? ' has-danger' : ''); ?>">
                                                        <div class="col-3">
                                                            <label class="form-control-label" for="input-commission_per"><?php echo e(__('Gambo Commission')); ?>

                                                                <br><?php echo e(__('(in Percentage)')); ?>:</label>
                                                        </div>
                                                        <div class="col-9">
                                                            <input type="number" name="commission_per" min="0" id="input-commission_per"
                                                                class="form-control form-control-alternative<?php echo e($errors->has('commission_per') ? ' is-invalid' : ''); ?>"
                                                                placeholder="<?php echo e(__('Gambo commission in percentage')); ?>" value="<?php echo e($setting->commission_per); ?>">
                                                            <?php if($errors->has('commission_per')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('commission_per')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    
                                            
                                            <div class="form-group row <?php echo e($errors->has('delivery_charge_per') ? ' has-danger' : ''); ?>">
                                                <div class="col-3">
                                                    <label class="form-control-label"
                                                        for="input-delivery_charge_per"><?php echo e(__('Delivery charge per order')); ?><br><?php echo e(__('(in Percentage)')); ?>:</label>
                                                </div>
                                                <div class="col-9">
                                                    <input type="number" name="delivery_charge_per" min="0" id="input-delivery_charge_per"
                                                        class="form-control form-control-alternative<?php echo e($errors->has('delivery_charge_per') ? ' is-invalid' : ''); ?>"
                                                        placeholder="<?php echo e(__('Delivery charge per order(in Percentage)')); ?>"
                                                        value="<?php echo e($setting->delivery_charge_per); ?>">
                                                    <?php if($errors->has('delivery_charge_per')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('delivery_charge_per')); ?></strong>
                                                    </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="text-right">
                                                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                            </div>
                                            </div>
                                            </form>
                                            </div>
                                            
                                            
                                            <div class="tab-pane" id="notification-va">
                                                <form method="post" action="<?php echo e(url('saveNotificationSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Push Notification Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group<?php echo e($errors->has('push_notification') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-3"> <label class="form-control-label"><?php echo e(__('Enable Push Notification')); ?></label>
                                                                </div>
                                                                <div class="col-9">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($setting->push_notification == 1?'checked':''); ?>

                                                                            name="push_notification" id="push_notification">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                            
                                            
                                                        <div class="form-group row <?php echo e($errors->has('onesignal_api_key') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-onesignal_api_key"><?php echo e(__('One Signal Rest Api Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="onesignal_api_key" id="input-onesignal_api_key"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('onesignal_api_key') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('One Signal Rest Api Key')); ?>" value="<?php echo e($setting->onesignal_api_key); ?>">
                                                                <?php if($errors->has('onesignal_api_key')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('onesignal_api_key')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                                        <div class="form-group row <?php echo e($errors->has('onesignal_auth_key') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-onesignal_auth_key"><?php echo e(__('One Signal Auth Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="onesignal_auth_key" id="input-onesignal_auth_key"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('onesignal_auth_key') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('One Signal Auth Key')); ?>" value="<?php echo e($setting->onesignal_auth_key); ?>">
                                                                <?php if($errors->has('onesignal_auth_key')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('onesignal_auth_key')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                            
                                                        <div class="form-group row <?php echo e($errors->has('onesignal_app_id') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-onesignal_app_id"><?php echo e(__('One Signal AppID')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="onesignal_app_id" id="input-onesignal_app_id"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('onesignal_app_id') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('One Signal AppID')); ?>" value="<?php echo e($setting->onesignal_app_id); ?>">
                                                                <?php if($errors->has('onesignal_app_id')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('onesignal_app_id')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('onesignal_project_number') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-onesignal_project_number"><?php echo e(__('One Signal Project No.')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="onesignal_project_number" id="input-onesignal_project_number"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('onesignal_project_number') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('One Signal Project No.')); ?>"
                                                                    value="<?php echo e($setting->onesignal_project_number); ?>">
                                                                <?php if($errors->has('onesignal_project_number')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('onesignal_project_number')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                            
                                            
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="tab-pane" id="mail-v">
                                                <form method="post" action="<?php echo e(url('saveMailSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("SMTP Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group<?php echo e($errors->has('mail_notification') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-3"> <label class="form-control-label"><?php echo e(__('Enable Mail Notification')); ?></label>
                                                                </div>
                                                                <div class="col-9">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($setting->mail_notification == 1?'checked':''); ?>

                                                                            name="mail_notification" id="mail_notification">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                            
                                                        <div class="form-group row <?php echo e($errors->has('mail_host') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-mail_host"><?php echo e(__('Mail Host')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="mail_host" id="input-mail_host"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('mail_host') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Mail Host')); ?>">
                                                                <?php if($errors->has('mail_host')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('mail_host')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('mail_port') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-mail_port"><?php echo e(__('Mail Port')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="mail_port" id="input-mail_port"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('mail_port') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Mail Port')); ?>">
                                                                <?php if($errors->has('mail_port')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('mail_port')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('mail_username') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-mail_username"><?php echo e(__('Mail UserName')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="mail_username" id="input-mail_username"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('mail_username') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Mail UserName')); ?>">
                                                                <?php if($errors->has('mail_username')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('mail_username')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('mail_password') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-mail_password"><?php echo e(__('Mail Password')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="mail_password" id="input-mail_password"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('mail_password') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Mail Password')); ?>">
                                                                <?php if($errors->has('mail_password')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('mail_password')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('sender_email') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-sender_email"><?php echo e(__('Sender Email ID')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="sender_email" id="input-sender_email"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('sender_email') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Sender Email ID')); ?>">
                                                                <?php if($errors->has('sender_email')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('sender_email')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="tab-pane" id="sms-v">
                                                <form method="post" action="<?php echo e(url('saveSMSSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("SMS Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group<?php echo e($errors->has('sms_twilio') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-3"> <label class="form-control-label"><?php echo e(__('Enable SMS Notification')); ?></label>
                                                                </div>
                                                                <div class="col-9">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($setting->sms_twilio == 1?'checked':''); ?>

                                                                            name="sms_twilio" id="sms_twilio">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                            
                                            
                                            
                                                        <div class="form-group row <?php echo e($errors->has('twilio_account_id') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-twilio_account_id"><?php echo e(__('Twilio Account ID')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="twilio_account_id" id="input-twilio_account_id"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('twilio_account_id') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Twilio Account ID')); ?>" value="<?php echo e($setting->twilio_account_id); ?>">
                                                                <?php if($errors->has('twilio_account_id')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('twilio_account_id')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('twilio_auth_token') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-twilio_auth_token"><?php echo e(__('Twilio Auth Token')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="twilio_auth_token" id="input-twilio_auth_token"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('twilio_auth_token') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Twilio Auth Token')); ?>" value="<?php echo e($setting->twilio_auth_token); ?>">
                                                                <?php if($errors->has('twilio_auth_token')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('twilio_auth_token')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                                        <div class="form-group row <?php echo e($errors->has('twilio_phone_number') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-twilio_phone_number"><?php echo e(__('Twilio Phone Number')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="twilio_phone_number" id="input-twilio_phone_number"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('twilio_phone_number') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Twilio Phone Number')); ?>" value="<?php echo e($setting->twilio_phone_number); ?>">
                                                                <?php if($errors->has('twilio_phone_number')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('twilio_phone_number')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                            
                                            
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            
                                            <div class="tab-pane" id="map-v">
                                                <form method="post" action="<?php echo e(url('saveMapSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Map Setting")); ?></h6>
                                                    <div>
                                                        <div class="form-group row <?php echo e($errors->has('map_key') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-map_key"><?php echo e(__('Map Api Key')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="map_key" id="input-map_key"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('map_key') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Map api key')); ?>" value="<?php echo e($setting->map_key); ?>" required>
                                                                <?php if($errors->has('map_key')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('map_key')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                            
                                                                <p class="mt-4" style="font-weight:400;font-size:15px;letter-spacing: .5px;">
                                                                    <?php echo e(__('The Maps JavaScript API lets you customize maps with your own content and imagery for display on web pages and mobile devices. See')); ?>

                                                                    <a
                                                                        href="https://developers.google.com/maps/documentation/javascript/get-api-key"><?php echo e(__('Get API Key')); ?></a>
                                                                    <?php echo e(__('for more information')); ?>.</p>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group row <?php echo e($errors->has('lat') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-lat"><?php echo e(__('Default Latitude')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="lat" id="input-lat"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('lat') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Default Latitude')); ?>" value="<?php echo e($setting->lat); ?>">
                                                                <?php if($errors->has('lat')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('lat')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row <?php echo e($errors->has('lang') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label"
                                                                    for="input-lang"><?php echo e(__('Default Longitude')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="text" name="lang" id="input-lang"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('lang') ? ' is-invalid' : ''); ?>"
                                                                    placeholder="<?php echo e(__('Default Longitude')); ?>" value="<?php echo e($setting->lang); ?>">
                                                                <?php if($errors->has('lang')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('lang')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="tab-pane" id="point-v">
                                                <form method="post" action="<?php echo e(url('savePointSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("Loyalty Point Setting")); ?></h6>

                                                    <div>                                                                                                   
                                                        <div class="form-group<?php echo e($errors->has('enable_point') ? ' has-danger' : ''); ?>">
                                                            <div class="row">
                                                                <div class="col-3"> <label class="form-control-label"><?php echo e(__('Enable Loyalty Point System')); ?></label>
                                                                </div>
                                                                <div class="col-9">
                                                                    <label class="custom-toggle">
                                                                        <input type="checkbox" value="1" <?php echo e($point->enable_point == 1?'checked':''); ?>

                                                                            name="enable_point" id="sms_twilio">
                                                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                                                            data-label-on="Yes"></span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row <?php echo e($errors->has('point_per_order') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-point_per_order"><?php echo e(__('Point per Order')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="point_per_order" placeholder="Point per Order" value="<?php echo e($point->point_per_order); ?>"  id="input-point_per_order" class="form-control form-control-alternative<?php echo e($errors->has('point_per_order') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('point_per_order')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('point_per_order')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('value_per_point') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-value_per_point"><?php echo e(__('Value of each point')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="value_per_point" placeholder="Value of each point" value="<?php echo e($point->value_per_point); ?>"  id="input-value_per_point" class="form-control form-control-alternative<?php echo e($errors->has('value_per_point') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('value_per_point')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('value_per_point')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('max_order_for_point') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-max_order_for_point"><?php echo e(__('Maximum Order for Point')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="max_order_for_point" placeholder="Maximum Order for Point" value="<?php echo e($point->max_order_for_point); ?>"  id="input-max_order_for_point" class="form-control form-control-alternative<?php echo e($errors->has('max_order_for_point') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('max_order_for_point')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('max_order_for_point')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('min_cart_value_for_point') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-min_cart_value_for_point"><?php echo e(__('Minimum cart value')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="min_cart_value_for_point" placeholder="Minimum cart value" value="<?php echo e($point->min_cart_value_for_point); ?>"  id="input-min_cart_value_for_point" class="form-control form-control-alternative<?php echo e($errors->has('min_cart_value_for_point') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('min_cart_value_for_point')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('min_cart_value_for_point')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row <?php echo e($errors->has('max_redeem_amount') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-max_redeem_amount"><?php echo e(__('Maximum reedem Amount')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="max_redeem_amount" placeholder="Maximum reedem Amount" value="<?php echo e($point->max_redeem_amount); ?>"  id="input-max_redeem_amount" class="form-control form-control-alternative<?php echo e($errors->has('max_redeem_amount') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('max_redeem_amount')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('max_redeem_amount')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        
                                            
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                            <div class="tab-pane" id="additional-v">
                                                <form method="post" action="<?php echo e(url('saveSettings')); ?>" autocomplete="off" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                            
                                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__("General Setting")); ?></h6>
                                                    <div>
                                            
                                                        <div class="form-group row <?php echo e($errors->has('currency') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-currency"><?php echo e(__('Currency')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <select name="currency" id="input-currency"
                                                                    class="form-control form-control-alternative<?php echo e($errors->has('currency') ? ' is-invalid' : ''); ?>"
                                                                    required>
                                                                    <option value="">Select Currency</option>
                                                                    <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($item->code); ?>" <?php echo e($setting->currency==$item->code?'Selected' : ''); ?>>
                                                                        <?php echo e($item->currency.' ( '.$item->symbol.' )'); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                                <?php if($errors->has('currency')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('currency')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        

                                                        <div class="form-group row <?php echo e($errors->has('default_grocery_order_status') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-default_grocery_order_status"><?php echo e(__('Default Order Status for Grocery')); ?>:</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <select name="default_grocery_order_status" id="input-default_grocery_order_status" class="form-control form-control-alternative<?php echo e($errors->has('default_grocery_order_status') ? ' is-invalid' : ''); ?>" required>
                                                                    <option value="">Select Defaut order Status</option>
                                                                    <option value="Pending" <?php echo e($setting->default_grocery_order_status=="Pending"?'Selected' : ''); ?>>Pending</option>
                                                                    <option value="Approved" <?php echo e($setting->default_grocery_order_status=="Approved"?'Selected' : ''); ?>>Approved</option>
                                                                </select>
                                                                <?php if($errors->has('default_grocery_order_status')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('default_grocery_order_status')); ?></strong>
                                                                </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row <?php echo e($errors->has('request_duration') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-request_duration"><?php echo e(__('Request Duration')); ?> (in MS):</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="request_duration" placeholder="Enter request duratetion in Milliseconds" value="<?php echo e($setting->request_duration); ?>"  id="input-request_duration" class="form-control form-control-alternative<?php echo e($errors->has('request_duration') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('request_duration')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('request_duration')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        <div class="form-group row <?php echo e($errors->has('delivery_charge') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-delivery_charge"><?php echo e(__('Delivery charges')); ?></label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="0" name="delivery_charge" placeholder="Enter Delivery charges" value="<?php echo e($setting->delivery_charge); ?>"  id="input-delivery_charge" class="form-control form-control-alternative<?php echo e($errors->has('delivery_charge') ? ' is-invalid' : ''); ?>" required>                                                                                                                                 
                                                                <?php if($errors->has('delivery_charge')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('delivery_charge')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        

                                                        <div class="form-group row <?php echo e($errors->has('default_driver_radius') ? ' has-danger' : ''); ?>">
                                                            <div class="col-3">
                                                                <label class="form-control-label" for="input-default_driver_radius"><?php echo e(__('Default radius of Driver (in KM):')); ?> (in KM):</label>
                                                            </div>
                                                            <div class="col-9">
                                                                <input type="number" min="1" name="default_driver_radius" placeholder="Enter default radius of Driver" value="<?php echo e($setting->default_driver_radius); ?>"  id="input-default_driver_radius" class="form-control form-control-alternative<?php echo e($errors->has('default_driver_radius') ? ' is-invalid' : ''); ?>" required>
                                                                <?php if($errors->has('default_driver_radius')): ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($errors->first('default_driver_radius')); ?></strong>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>

                                                        
                                                        <div class="text-right">
                                                            <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>

                                             
                                        

                                    </div>                                
                                </div>
                            </div>
                        </div>                        
                    </div>
            </div>
        </div>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Settings')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/setting/setting.blade.php ENDPATH**/ ?>