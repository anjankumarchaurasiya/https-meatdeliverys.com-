
<?php $__env->startSection('title', __('Offers')); ?>

<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Offers')); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <div class="all-product-grid mb-14">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="default-title mt-4">
                        <h2> <?php echo e(__('Offers')); ?> </h2>
                        <img src="<?php echo e(url('/frontend/images/line.svg')); ?>" alt="">
                    </div>
                </div>
                <?php if(count($coupons) > 0): ?>
                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="offers-item">
                                <div class="offer-img">
                                    <img src="<?php echo e($item->imagePath . $item->image); ?>" alt="">
                                </div>
                                <div class="offers-text">
                                    <h4>📢 <?php echo e($item->name); ?></h4>
                                    <h5><?php echo e($item->code); ?></h5>
                                    <p><?php echo e($item->description); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-lg-12 col-md-12">
                        <div class="how-order-steps">
                            <div class="how-order-icon">
                                <i class="uil uil-gift"></i>
                            </div>
                            <h4> <?php echo e(__('No Offers Available')); ?> </h4>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>	
</div>
<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/frontend/offers.blade.php ENDPATH**/ ?>