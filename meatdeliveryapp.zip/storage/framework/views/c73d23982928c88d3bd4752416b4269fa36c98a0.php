<div class="header pb-7 pt-5 pt-lg-8 d-flex align-items-center" style="background-image: url(<?php echo e(url('admin/images/bg.jpg')); ?>); background-size: cover; background-position: center center;">
    <span class="mask bg-gradient-default opacity-8"></span>
    <div class="container-fluid align-items-center">
        

        <div class="row align-items-center py-4">
                <div class="col-lg-9 col-9">
                    <h6 class="h2 text-white d-inline-block mb-0" style="font-size:30px;"><?php echo e($title); ?></h6>
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <?php if(Auth::check()): ?>
                            <li class="breadcrumb-item text-white"><a href="<?php echo e(url('home')); ?>"><i class="fas fa-home"></i></a></li>
                            <?php elseif(Auth::guard('mainAdmin')->check()): ?>
                            <li class="breadcrumb-item text-white"><a href="<?php echo e(url('mainAdmin/home')); ?>"><i class="fas fa-home"></i></a></li>
                            <?php endif; ?>
                            <?php if(isset($headerData) && $headerData): ?>
                            <li class="breadcrumb-item text-white"><a href="<?php echo e(url($url)); ?>"><?php echo e($headerData); ?></a></li>
                            <?php endif; ?>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?></li>
                        </ol>
                    </nav>
                </div>
        </div>

    </div>





</div>
<?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/layout/topHeader.blade.php ENDPATH**/ ?>