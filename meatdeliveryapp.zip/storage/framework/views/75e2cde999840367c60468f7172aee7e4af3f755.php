<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Grocery Item') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

        <div class="row">
            <div class="col">
                <div class="card form-card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0"><?php echo e(__('Grocery Item')); ?></h3>
                            </div>
                            <div class="col-4 text-right">
                                <a href="<?php echo e(url('GroceryItem/create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Add New Item')); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <?php if(count($items)>0): ?>
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col"><?php echo e(__('#')); ?></th>
                                        <th scope="col"><?php echo e(__('Image')); ?></th>
                                        <th scope="col"><?php echo e(__('Name')); ?></th>
                                        <th scope="col"><?php echo e(__('Category')); ?></th>
                                        <th scope="col"><?php echo e(__('Shop')); ?></th>
                                        <th scope="col"><?php echo e(__('Price')); ?></th>
                                        <th scope="col"><?php echo e(__('Status')); ?></th>
                                        <th scope="col"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><img class=" avatar-lg rou  nd-5" src="<?php echo e(url('images/upload/'.$item->image)); ?>"></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->category->name); ?></td>
                                            <td><?php echo e($item->shopName); ?></td>
                                            <td><strike><?php echo e($currency.$item->fake_price); ?></strike><?php echo e($currency.$item->sell_price); ?></td>

                                            <td>
                                                <span class="badge badge-dot mr-4">
                                                    <i class="<?php echo e($item->status==0?'bg-success': 'bg-danger'); ?>"></i>
                                                    <span class="status"><?php echo e($item->status==0?'Avaliable': 'Not avaliable'); ?></span>
                                                </span>
                                            </td>
                                            <td>
                                                
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-men
                                                    u-right dropdown-menu-arrow">
                                                        
                                                        <a class="dropdown-item" href="<?php echo e(url('GroceryItem/'.$item->id.'/edit')); ?>"><?php echo e(__('Edit')); ?></a>
                                                        <a class="dropdown-item" href="<?php echo e(url('GroceryItem/gallery/'.$item->id.'/edit')); ?>"><?php echo e(__('Gallery')); ?></a>
                                                        <a class="dropdown-item" onclick="deleteData('GroceryItem','<?php echo e($item->id); ?>');" href="#"><?php echo e(__('Delete')); ?></a>
                                                        
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $items->render(); ?>
                        <?php else: ?>
                            <div class="empty-state text-center pb-3">
                                <img src="<?php echo e(url('images/empty3.png')); ?>" style="width:35%;height:220px;">
                                <h2 class="pt-3 mb-0" style="font-size:25px;"><?php echo e(__('Nothing!!')); ?></h2>
                                <p style="font-weight:600;"><?php echo e(__('Your Collection list in empty....')); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __('Items')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/groceryat/public_html/resources/views/admin/GroceryItem/viewGroceryItem.blade.php ENDPATH**/ ?>