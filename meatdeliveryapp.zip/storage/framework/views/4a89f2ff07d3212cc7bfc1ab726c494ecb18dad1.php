<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __($data->name) ,
        'headerData' => __('Grocery Shops') ,
        'url' => 'GroceryShop' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

        <div class="row">
            <div class="col">
                    <div class="card form-card shadow" style="border:none;" >
                        <div class="card-top-header"  style="background-image: url(<?php echo e(url('images/upload/'.$data->cover_image)); ?>);">
                        </div>
                        <div class="card-body shop-detail">
                            <div class="row">
                                <div class="col-6">
                                    <h2 class="m-0"><?php echo e($data->name); ?></h2>
                                    <p class="m-0"><?php echo e($data->address); ?></p>
                                    <p class="m-0"><?php echo e($data->locationData?$data->locationData->name:'-'); ?></p>
                                    <?php if($data->phone!=null): ?>
                                    <p class="m-0"><?php echo e('(p) : +91 '.$data->phone); ?></p>
                                    <?php else: ?>
                                    <p class="m-0"><?php echo e('(p) : +91 '.Auth::user()->phone); ?></p>
                                    <?php endif; ?>
                                    <p><?php echo e($data->website); ?></p>

                                    <input type="hidden" id="latitude" value="<?php echo e($data->latitude); ?>" name="latitude">
                                    <input type="hidden" id="longitude" value="<?php echo e($data->longitude); ?>" name="longitude">
                                    <input type="hidden" id="shop_name" value="<?php echo e($data->name); ?>" name="shop_name">
                                    <input type="hidden" id="radius" value="<?php echo e($data->radius); ?>" name="radius">

                                </div>
                                <div class="col-6 text-right">
                                    <img src="<?php echo e(url('images/upload/'.$data->image)); ?>" style="width:180px;height:60px;margin-bottom:20px">
                                    <div class="rating">
                                        <?php for($i =1 ; $i <= 5; $i++): ?>
                                            <i class="fas fa-star <?php echo e($i<=$data->rate ? 'active' : ''); ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                    <span class="badge rate-label mt-1"><?php echo e($data->rate); ?>(<?php echo e($data->totalReview); ?>)</span>
                                </div>
                               <div class="col-12">
                                    <hr class="mt-2 mb-1">
                               </div>
                               <div class="col-12 row shop-data">
                                    <div class="col-6 pl-4">
                                        <h4><?php echo e(__('Opening Hours')); ?></h4>
                                        <p><?php echo e($data->open_time.' - '.$data->close_time); ?></p>
                                    </div>
                               </div>
                                <div class="col-12">
                                    <hr class="mt-1 mb-2">
                                </div>
                                <div class="col-12 shop-bottom">

                                    <h3 class="mt-4 mb-4"><?php echo e(__('Address')); ?>:</h3>
                                    <div id="shop_map" class="mb-5 " style="width: 530px; height: 250px; border-radius:5px; border:1px solid rgba(120, 130, 140, 0.2);"></div>
                                </div>
                            </div>

                        </div>
                    </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __($data->name)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/GroceryShop/groceryShopDetail.blade.php ENDPATH**/ ?>