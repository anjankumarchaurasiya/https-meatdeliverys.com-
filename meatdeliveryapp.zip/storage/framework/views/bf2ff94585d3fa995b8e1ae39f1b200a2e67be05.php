<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Edit SubCategory') ,
        'headerData' => __('SubCategory') ,
        'url' => 'GrocerySubCategory' ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid mt--7">

            <div class="row">
                    <div class="col-xl-12 order-xl-1">
                        <div class="card form-card bg-secondary shadow">
                            <div class="card-header bg-white border-0">
                                <div class="row align-items-center">
                                    <div class="col-8">
                                        <h3 class="mb-0"><?php echo e(__('Edit SubCategory')); ?></h3>
                                    </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(url('GrocerySubCategory')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Back to list')); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <form method="post" action="<?php echo e(url('GrocerySubCategory/'.$data->id)); ?>" class="grocery_subcategory" autocomplete="off" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Category Detail')); ?></h6>
                                    <div class="pl-lg-4">
                                        <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-name"><?php echo e(__('Name')); ?></label>
                                            <input type="text" name="name" id="input-name" class="form-control form-control-alternative<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Name')); ?>" value="<?php echo e($data->name); ?>" required autofocus>
                                            <?php if($errors->has('name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group<?php echo e($errors->has('category_id') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-category_id"><?php echo e(__('Category')); ?></label>
                                            <Select name="category_id" id="input-category_id" class="form-control form-control-alternative<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>"  required>
                                                <option value="">Select Category</option>
                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e($data->category_id==$item->id ? 'Selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <?php if($errors->has('category_id')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('category_id')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="row">
                                            <div class="col-10">
                                                <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                    <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                    <div class="custom-file">
                                                        <input type="file"  accept=".png, .jpg, .jpeg, .svg" class="custom-file-input read-image" name="image" id="image">
                                                        <label class="custom-file-label" for="image">Select file</label>
                                                    </div>
                                                    <?php if($errors->has('image')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('image')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-2">
                                                <img class=" avatar-lg round-5 view-image" style="width: 100%;height: 90px;" src="<?php echo e(url('images/upload/'.$data->image)); ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="form-group<?php echo e($errors->has('status') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-status"><?php echo e(__('Status')); ?></label>
                                            <Select name="status" id="input-status" class="form-control form-control-alternative<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>"  required>
                                                <option value="">Select Status</option>
                                                <option value="0" <?php echo e($data->status=="0" ? 'Selected' : ''); ?>>Avaliable</option>
                                                <option value="1" <?php echo e($data->status=="1" ? 'Selected' : ''); ?>>Not Avaliable</option>
                                            </select>

                                            <?php if($errors->has('status')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('status')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', ['title' => __('Edit Category')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/admin/SubCategory/editSubCategory.blade.php ENDPATH**/ ?>