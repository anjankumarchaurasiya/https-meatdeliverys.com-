

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.layout.topHeader', [
        'title' => __('Notification Template') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php if(Session::has('msg')): ?>
        <?php echo $__env->make('toast',Session::get('msg'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <div class="container-fluid mt--7">
           
        <div class="row">
            <div class="col">
                    <div class="card bg-secondary shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0"><?php echo e(__('Notification Template')); ?></h3>
                                </div>
                                <div class="col-4 text-right">
                                    
                                </div>
                            </div>
                        </div>

                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">
                                    <div class="template-left">
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($loop->iteration==1): ?>
                                                <?php $template = $item;?>
                                            <?php endif; ?>
                                            <div class="template-row mb-4">
                                                <img src="<?php echo e(url('images/upload/'.$item->image)); ?>" class="avatar round-5">
                                                <button onclick="notificationDetail(<?php echo e($item->id); ?>);" class="btn btn-primary template-btn"> <?php echo e($item->title); ?></button>    
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </div>
                                </div>
                                <div class="col-7">
                                        <form method="post" action="<?php echo e(url('NotificationTemplate/'.$template->id)); ?>" id="edit-template-form" autocomplete="off" enctype="multipart/form-data" >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Edit Template')); ?></h6>
                                            <div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <div class="form-group<?php echo e($errors->has('subject') ? ' has-danger' : ''); ?>">                                            
                                                            <label class="form-control-label" for="input-subject"><?php echo e(__('Subject')); ?></label>
                                                            <input type="text" name="subject" id="input-subject" class="form-control form-control-alternative<?php echo e($errors->has('subject') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Subject')); ?>" value="<?php echo e(isset($template) ? $template->subject: ''); ?>" required >
                                                            <?php if($errors->has('subject')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('subject')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="form-group<?php echo e($errors->has('image') ? ' has-danger' : ''); ?>">
                                                            <label class="form-control-label" for="input-image"><?php echo e(__('Image')); ?></label>
                                                                <div class="custom-file">
                                                                <input type="file" accept=".png, .jpg, .jpeg, .svg" class="custom-file-input" name="image" id="image" >
                                                                <label class="custom-file-label" for="image">Select file</label>
                                                                </div>
                                                            <?php if($errors->has('image')): ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($errors->first('image')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>  
                                                    </div>
                                                </div>
                                                <input type="hidden" id="content-data" name="content-text" value="<?php echo e(isset($template) ? $template->mail_content: ''); ?>" >
                                                <div class="form-group<?php echo e($errors->has('mail_content') ? ' has-danger' : ''); ?>">                                            
                                                    <label class="form-control-label" for="input-mail_content"><?php echo e(__('Content for Mail')); ?></label>
                                                    <textarea name="mail_content" placeholder="Enter Content" rows="10" id="input-mail_content" class="form-control textarea_editor form-control-alternative<?php echo e($errors->has('mail_content') ? ' is-invalid' : ''); ?>" required ></textarea>
                                                    <?php if($errors->has('mail_content')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('mail_content')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('message_content') ? ' has-danger' : ''); ?>">                                            
                                                    <label class="form-control-label" for="input-message_content"><?php echo e(__('Content for Message')); ?></label>
                                                    <textarea name="message_content"  id="input-message_content" class="form-control form-control-alternative<?php echo e($errors->has('message_content') ? ' is-invalid' : ''); ?>" ><?php echo e(isset($template) ? $template->message_content: ''); ?></textarea>
                                                    <?php if($errors->has('message_content')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('message_content')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>        
                                                <div class="text-center">
                                                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                </div>
                                <div class="col-2">
                                    <h6 class="heading-small text-muted mb-4"><?php echo e(__('Email Placeholder')); ?></h6>
                                    <div class="mail-placeholder">  
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="Receiver name">{{name}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="Order ID">{{order_no}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="User Address">{{user_address}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="Payment Status">{{payment_status}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="Order Status">{{status}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="Cusetomer name">{{customer_name}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="New Password">{{password}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="User Verification code">{{otp}}</button>
                                        <button type="button" class="btn btn-sm" data-toggle="tooltip" data-placement="top" title="System Name">{{shop_name}}</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
            </div>
        </div>       
        <div class="test-mail-section">
            <span><button type="button" data-toggle="modal" data-target="#exampleModal" class="btn" title="Send test mail"><i class="far fa-envelope"></i></button></span>
        </div>
    </div>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Send Test Mail')); ?></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body bg-secondary">
                <form method="post" action="<?php echo e(url('sendTestMail')); ?>">
                        <?php echo csrf_field(); ?>                        
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">                                            
                                <label class="form-control-label" for="input-email"><?php echo e(__('Recipient Email')); ?></label>
                                <input type="email" name="email" id="input-email" class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Recipient Email')); ?>" value="" required autofocus>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                          
                            <div class="form-group<?php echo e($errors->has('template_id') ? ' has-danger' : ''); ?>">                                            
                                <label class="form-control-label"   style="display:block;"for="input-template_id"><?php echo e(__('Notification Template')); ?></label>
                                <select type="text" name="template_id" id="input-template_id" class=" select2 form-control form-control-alternative<?php echo e($errors->has('template_id') ? ' is-invalid' : ''); ?>" required >
                                    <option value="" selected>Select Mail Template</option>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('template_id')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('template_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>  
                            <div class="form-group text-right"> 
                                <button type="button" class="btn" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                <button  type="submit" class="btn btn-primary"><?php echo e(__('Send')); ?></button>   
                            </div>                                              
                   </form>
                </div>
                
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', ['title' => __('Notification Template')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/mainAdmin/notification/viewNotification.blade.php ENDPATH**/ ?>