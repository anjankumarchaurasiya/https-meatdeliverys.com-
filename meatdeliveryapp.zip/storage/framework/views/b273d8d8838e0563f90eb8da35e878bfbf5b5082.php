
<?php $__env->startSection('title', __('Orders')); ?>

<?php $__env->startSection('content'); ?>

<!-- Body Start -->
<div class="wrapper">
    <div class="gambo-Breadcrumb">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"> <?php echo e(__('Home')); ?> </a></li>
                            <li class="breadcrumb-item active" aria-current="page"> <?php echo e(__('Dashboard')); ?> </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('frontend.model.user-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="">
        <div class="container">
            <div class="row">
                <?php echo $__env->make('frontend.model.user-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-lg-9 col-md-8">
                    <div class="dashboard-right">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="main-title-tab">
                                    <h4><i class="uil uil-box"></i><?php echo e(__('My Orders')); ?></h4>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="pdpt-bg">
                                        <div class="pdpt-title">
											<h6> <?php echo e(__("Order Placed : ")); ?> <?php echo e($order->date. ' '. $order->time); ?> </h6>
										</div> 
                                        <div class="order-body10">
                                            <?php
                                                $ar = array(); 
                                                foreach ($order->orderItem as $item) {
                                                    $push = $item->itemName .' '. $item->unit_qty. $item->unit .' * '. $item->quantity;
                                                    array_push($ar, $push);
                                                }
                                            ?>
                                            <ul class="order-dtsll">
                                                <li>
                                                    <div class="order-dt-img">
                                                        <img src="<?php echo e(url('/frontend/images/groceries.svg')); ?>" alt="">
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="order-dt47">
                                                        <h4><?php echo e($company->name); ?> - <?php echo e($order->location->name); ?></h4>
                                                        <div class="order-title"><?php echo e(count($order->orderItem)); ?> <?php echo e(__('Items')); ?> <span data-inverted="" data-tooltip="<?php echo e(implode(', ', $ar)); ?>" data-position="top center">?</span></div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div class="total-dt">
                                                <div class="total-checkout-group">
                                                    <div class="cart-total-dil">
                                                        <h4><?php echo e(__('Sub Total')); ?></h4>
                                                        <span><?php echo e($data["currency"]); ?><?php echo e($order->payment - $order->delivery_charge - $order->discount); ?></span>
                                                    </div>
                                                    <?php if($order->discount > 0): ?>
                                                        <div class="cart-total-dil pt-3">
                                                            <h4><?php echo e(__("Discount")); ?></h4>
                                                            <span><?php echo e($data["currency"] . $order->discount); ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                    <?php if($order->delivery_charge > 0): ?>
                                                        <div class="cart-total-dil pt-3">
                                                            <h4><?php echo e(__("Delivery Charges")); ?></h4>
                                                            <span><?php echo e($data["currency"] . $order->delivery_charge); ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="main-total-cart">
                                                    <h2><?php echo e(__('Total')); ?></h2>
                                                    <span><?php echo e($data["currency"] . $order->payment); ?></span>
                                                </div>
                                            </div>
                                            <div class="track-order">
                                                <h4><?php echo e(__('Track Order')); ?></h4>
                                                <?php
                                                    $status = $order->order_status;
                                                ?>
                                                <div class="bs-wizard" style="border-bottom:0;">   
                                                    <div class="bs-wizard-step <?php echo e($status == "Pending" || $status == "Approved" || $status == "Prepare" ? 'active':'complete'); ?>">
                                                        <div class="text-center bs-wizard-stepnum"><?php echo e(__('Placed')); ?></div>
                                                        <div class="progress"><div class="progress-bar"></div></div>
                                                        <a href="#" class="bs-wizard-dot"></a>
                                                    </div>
                                                    
                                                    <div class="bs-wizard-step <?php echo e($status == "Pending" || $status == "Approved" || $status == "Prepare" ? 'disabled':''); ?><?php echo e($status == "OrderReady" || $status == "DriverReach" || $status == "DriverApproved" || $status == "DriverAtShop" ? 'active':''); ?><?php echo e($status == "OutOfDelivery" || $status == "PickUpGrocery" || $status == "OneTheWay" || $status == "Delivered" ? 'complete':''); ?>">
                                                        <div class="text-center bs-wizard-stepnum"><?php echo e(__('Packed')); ?></div>
                                                        <div class="progress"><div class="progress-bar"></div></div>
                                                        <a href="#" class="bs-wizard-dot"></a>
                                                    </div>
                                                    <div class="bs-wizard-step <?php echo e($status == "Pending" || $status == "Approved" || $status == "Prepare" || $status == "OrderReady" || $status == "DriverReach" || $status == "DriverApproved" || $status == "DriverAtShop" ? 'disabled':''); ?><?php echo e($status == "OutOfDelivery" || $status == "PickUpGrocery" || $status == "OneTheWay" ? 'active':''); ?><?php echo e($status == "Delivered" ? 'complete':''); ?>">
                                                        <div class="text-center bs-wizard-stepnum"><?php echo e(__('On the way')); ?></div>
                                                        <div class="progress"><div class="progress-bar"></div></div>
                                                        <a href="#" class="bs-wizard-dot"></a>
                                                    </div>
                                                    <div class="bs-wizard-step <?php echo e($status == "Delivered" ? 'active':'disabled'); ?>">
                                                        <div class="text-center bs-wizard-stepnum"><?php echo e(__('Delivered')); ?></div>
                                                        <div class="progress"><div class="progress-bar"></div></div>
                                                        <a href="#" class="bs-wizard-dot"></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="call-bill">
                                                <?php if(isset($order->deliveryBoy_id)): ?>
                                                    <div class="delivery-man">
                                                        <?php echo e(__('Delivery Boy')); ?> - <a href="tel:<?php echo e($order->deliveryGuy->phone_code . $order->deliveryGuy->phone); ?>"><i class="uil uil-phone"></i> <?php echo e(__('Call Us')); ?></a>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="order-bill-slip">
                                                    <a href="<?php echo e(url('invoice/'.$order->id)); ?>" target="_blank" class="bill-btn5 hover-btn"><?php echo e(__('View Invoice')); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>								
                        </div>
                    </div>
                </div>
            </div>	
        </div>	
    </div>	
</div>  
<!-- Body End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pharafmy/meatdeliverys.com/resources/views/frontend/profile-orders.blade.php ENDPATH**/ ?>